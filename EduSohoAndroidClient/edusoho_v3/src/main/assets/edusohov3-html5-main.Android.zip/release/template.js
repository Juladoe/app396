angular.module('app').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/alipay_modal.html',
    "<div class=\"alipay-modal modal\"><ion-header-bar class=\"bar-positive\"><a class=\"button button-icon iconfont icon-fanhui\" back=\"close\">关闭</a></ion-header-bar><ion-pane><iframe src=\"{{ payUrl }}\" height=\"100%\" width=\"100%\"></iframe></ion-pane></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/article.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">资讯</h3><div class=\"bar-tool\"><div class=\"ui-pop\" ui-pop><button class=\"ui-btn btn-outline iconfont icon-gengduo ui-pop-btn\"></button><div class=\"ui-pop-bg\" ng-show=\"isShowMenuPop\"></div><ul class=\"ui-pop-content\" ng-show=\"isShowMenuPop\"><li class=\"ui-border-b\"><a class=\"ui-btn btn-outline iconfont icon-shuaxin\" ng-click=\"refresh(this)\">刷新</a></li><li class=\"ui-border-b\"><a class=\"ui-btn btn-outline iconfont icon-fenxiang\" ng-click=\"share()\">分享</a></li></ul></div></div></div></div><div class=\"top-header ui-article ui-scroller\" ng-init=\"init()\"><section class=\"ui-panel\"><h2 class=\"ui-title\">{{ article.title }}</h2><div class=\"ui-subtitle\"><span class=\"time\">{{ article.createdTime | coverArticleTime }}</span> <span class=\"source\">{{ article.source }}</span></div><div class=\"ui-content\" ng-bind-html=\"article.body\" ng-img-show></div></section></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/category.html',
    "<div class=\"modal category-card\"><ion-content><category-tree data=\"categoryTree\" listener=\"categorySelectedListener\"></category-tree></ion-content></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/category_tree.html',
    "<ul class=\"ui-grid-trisect\"><li ng-class=\"'list_' + $index\" ng-repeat=\"categorys in categoryCols\"><ul class=\"ui-list ui-list-text ui-list-cover ui-border-tb\"><li class=\"ui-border-t\" ng-click=\"selectCategory($event, item)\" ng-repeat=\"item in categorys\"><p>{{ item.name }}</p></li></ul></li></ul>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/classroom.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"close\"></button><h3 class=\"title\">班级详情</h3><div class=\"bar-tool\" ng-show=\"classRoom && ! member\"><button class=\"ui-btn btn-outline iconfont icon-fenxiang\" ng-click=\"shardCourse()\"></button></div><div class=\"bar-tool\" ng-show=\"member\"><div class=\"ui-pop\" ui-pop><button class=\"ui-btn btn-outline iconfont icon-shezhi\" ng-click=\"showCourseSetting()\"></button></div></div></div></div><div ng-include=\"classRoomView\" style=\"height:100%\"></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/classroom_courses.html',
    "<ul class=\"ui-list ui-list-lesson\" ng-controller=\"ClassRoomCoursesController\" ng-init=\"initClassRoomPlay()\"><li class=\"{{ lesson.type }} ui-border-b\" ng-repeat=\"lesson in lessons\" ng-class=\"lesson.id == lastLearnStatusIndex ? 'color-green' : 'color-black' \" ng-click=\"learnLesson(lesson)\"><span class=\"icon-center\"><i class=\"iconfont mr-s\" ng-class=\" lesson | lessonIcon\" ng-if=\"lesson.type != 'live'\"></i></span><div class=\"ui-list-info ui-nowrap\" ng-class=\"lesson.type\"><span class=\"\">{{ lesson | formatChapterNumber }} {{ lesson.title }}</span></div><span ng-bind-html=\"classroomLearnStatuses[lesson.id] | lessonLearnStatusTag : lesson.type\" class=\"ml\" style=\"margin-right: -8px\"></span> <span ng-bind-html=\"lesson | lessonType\" class=\"ml mr\"></span> <span class=\"color-light-gray\"><span ng-if=\"lesson.type !='chapter' && lesson.type !='unit' \">{{ lesson.length | coverLessonLengthTime }}</span></span></li><list-empty-view class=\"lesson-empty\" data=\"lessons\" title=\"暂无学习轨迹\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"loading\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></ul>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/classroom_courses_learn.html',
    "<ul class=\"ui-list ui-list-lesson ui-border-b\" ng-controller=\"ClassRoomCoursesController\" ng-init=\"initClassRoomPlay()\"><li class=\"{{ lesson.type }} ui-border-b\" ng-repeat=\"lesson in lessons\" ng-class=\"lesson.id == lastLearnStatusIndex ? 'color-green' : 'color-black' \" ng-click=\"learnClassRoomLesson(lesson)\"><div class=\"ui-list-info\" ng-class=\"lesson.type == 'label' ? 'chapter' : lesson.type\"><h4 class=\"ui-nowrap\">{{ lesson | formatChapterNumber }} {{ lesson.title }}</h4></div><div class=\"ui-list-action lesson-time\" ng-if=\"lesson.type !='chapter' && lesson.type !='unit' \"><span><i class=\"iconfont icon-favor\"></i></span></div></li><list-empty-view class=\"lesson-empty\" data=\"lessons\" title=\"暂无学习轨迹\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"loading\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></ul>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/classroom_detail.html',
    "<div class=\"bg-light-white\"><section class=\"ui-panel ui-panel-card ui-border-t\"><h2 class=\"title-body\" style=\"font-size:17px\"><span class=\"title\">{{ classRoom.title }}</span></h2><div class=\"ui-panel-content\"><span class=\"rating-body\" ng-if=\"! member\"><i class=\"iconfont\" ng-class=\"(classRoom.rating | number : 0) > i ? 'icon-favorfill' : 'icon-favor' \" ng-repeat=\"i in ratingArray\"></i></span> <span ng-class=\"classRoom.price > 0 ? 'color-red' : '' \" style=\"top:2px\" class=\"price-block\" ng-if=\"! member && classRoom.priceType != 'Coin'\">{{ classRoom.price | formatPrice }}</span> <span ng-class=\"classRoom.price > 0 ? 'color-red' : '' \" style=\"top:2px\" class=\"price-block\" ng-if=\"! member && classRoom.priceType == 'Coin'\">{{ classRoom.coinPrice | formatPrice }}</span> <span style=\"top:2px\">{{ classRoom.studentNum }}名学生</span></div><!--  </section> --><!--   <section class=\"ui-panel ui-panel-card\" ng-if=\"classRoom.service.length > 0\"> --><div class=\"service-body\" ui-service-panel ng-if=\"classRoom.service.length > 0\"><hr width=\"100%\" color=\"#E1E1E1\" size=\"1/\"><ul class=\"ui-list\"><li ng-repeat=\"service in classRoom.service\" style=\"line-height:36px;height:30px\"><span class=\"label\">{{ service.name }}</span> <span class=\"title\">{{ service.title }}</span></li></ul><a class=\"service-btn\" expand=\"true\">{{ classRoom.service.length }}个服务 <i class=\"service-icon iconfont icon-arrowdropdown\"></i></a></div></section><section class=\"ui-panel ui-panel-card ui-panel-auto\" ui-auto-panel data=\"classRoomDetailContent\"><h3 class=\"class-title-body\"><span class=\"title\">班级介绍</span></h3><div class=\"ui-panel-content mt\" ng-bind-html=\"classRoomDetailContent\" ng-img-show style=\"font-size:12px\"></div><p class=\"ui-panel-autobtn\"><span class=\"autobtn-text\">展开</span> <i class=\"iconfont icon-expandmore autobtn-icon\"></i></p></section><section class=\"ui-panel ui-panel-card\" ng-init=\"loadTeachers()\"><h3 class=\"class-title-body\"><span class=\"title\">班主任</span></h3><div class=\"ui-panel-content mt\"><ul class=\"ui-list ui-list-link\"><li class=\"ui-border-t\" ng-if=\"teachers[0]\" ui-sref=\"userInfo({ userId : teachers[0].id })\"><div class=\"ui-avatar-s\"><img ng-src=\"{{ teachers[0].largeAvatar | coverAvatar }}\" img-error=\"avatar\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\" style=\"font-size:12px\">{{ teachers[0].nickname }}</h4><p class=\"ui-nowrap\" style=\"font-size:12px\">{{ teachers[0].title }}</p></div></li><li ng-if=\"! teachers[0]\"><p>该班级暂无教师</p></li></ul></div></section></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/classroom_discuss.html',
    "<ul class=\"ui-list list-link\" ng-controller=\"ClassRoomDiscussController\" ng-init=\"initThreads()\"><li class=\"ui-border-b padding-x\" ng-repeat=\"thread in threads\" ng-click=\"showThread(thread)\"><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\"><span ng-if=\"thread.type == 'question' \" class=\"label-x color-yellow font-s\">问答</span> <span ng-if=\"thread.type == 'discussion' \" class=\"label-x color-blue font-s\">话题</span> {{ thread.title }}</h4><p class=\"ui-nowrap-multi mt font-n\">{{ thread.content }}</p><ul class=\"ui-list inner mt\"><li class=\"ui-border-t\"><div class=\"ui-avatar-s xs\"><img ng-src=\"{{ thread.user.avatar }}\" img-error=\"avatar\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap ui-review-header font-s\">{{ thread.user.nickname }} <span>{{ thread.latestPostTime }}</span></h4></div></li></ul></div></li><list-empty-view class=\"lesson-empty\" data=\"threads\" title=\"暂无班级讨论\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"loading\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></ul>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/classroom_learn.html',
    "<div class=\"ui-course ui-classroom top-header ui-scroller\" style=\"padding-bottom: 58px;height:100%\"><div class=\"course-head-body\"><div class=\"course-head\"><img class=\"full-image\" ng-src=\"{{ classRoom.largePicture }}\" img-error=\"classroom\"></div></div><div class=\"ui-tab tab-top\" ui-tab height=\"auto\"><ul class=\"ui-tab-nav ui-border-tb\"><li><span>简介</span></li><li><span>轨迹</span></li><li><span>讨论</span></li></ul><ul class=\"ui-tab-content tab-display\"><li ng-onload=\"loadClassRoomDetail()\"><div ng-include=\" 'view/classroom_detail.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/classroom_courses.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/classroom_discuss.html' | coverIncludePath \"></div></li></ul></div></div><div ng-controller=\"ClassRoomToolController\"><div ng-show=\"!currentPage || currentPage < 2\"><div class=\"ui-course-tool bg-yellow color-white font-x\" ng-click=\"continueLearnCourse()\" style=\"box-shadow: 0 0 2px rgba(0, 0, 0, 0.5)\" ng-if=\"lastIndex == 0\"><i class=\"iconfont icon-shuben mr\"></i> <span>已加入、开始学习</span></div><div class=\"ui-course-tool bg-green color-white font-x\" ng-click=\"continueLearnCourse()\" style=\"box-shadow: 0 0 2px rgba(0, 0, 0, 0.5)\" ng-if=\"lastIndex > 0\"><i class=\"iconfont icon-shuben mr\"></i> <span>继续学习</span></div></div><div ng-show=\"currentPage == 2\"><div class=\"ui-course-tool color-white font-x padding-s\" style=\"box-shadow: 0 0 2px rgba(0, 0, 0, 0.5)\"><button class=\"ui-btn btn-green btn-col-45\" ng-click=\"postQuestion('classroom', classRoom.id)\">提问题</button> <button class=\"ui-btn btn-yellow btn-col-45\" ng-click=\"postQuestion('classroom', classRoom.id, 'discussion')\">发话题</button></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/classroom_list.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">班级搜索</h3></div></div><div class=\"ui-tab tab-top ui-courselist\" ui-tab select=\"empty\"><ul class=\"ui-tab-nav ui-border-b\"><li><span class=\"line\">{{ categoryTab.category }}<i class=\"iconfont icon-keyboardarrowdown\"></i></span></li><li><span class=\"line\">{{ categoryTab.sort }}<i class=\"iconfont icon-keyboardarrowdown\"></i></span></li></ul><ul class=\"ui-tab-content tab-display top-tab-header\" style=\"position: fixed\"><li modal><div class=\"content category-card\"><category-tree ng-if=\"categoryTree\" data=\"categoryTree\" listener=\"categorySelectedListener\"></category-tree></div><div class=\"backdrop-bg\"></div></li><li modal><div class=\"content\"><ul class=\"ui-list ui-list-text ui-list-cover ui-list-active\"><li class=\"ui-border-b\" ng-click=\"selectSort(item)\" ng-repeat=\"item in courseListSorts\">{{ item.name }}</li></ul></div><div class=\"backdrop-bg\"></div></li></ul><div class=\"ui-scroller course-card classroom-card\" ui-scroll data=\"classRooms\" on-infinite=\"loadMore(successCallback)\"><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"classRoom in classRooms\" ng-click=\"gotoNativeDetailClassroomPage(classRoom.id)\" ng-include=\" 'view/classroom_list_item.html' | coverIncludePath \"></li></ul><list-empty-view data=\"classRooms\" title=\"暂时没有班级\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoad\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/classroom_list_item.html',
    "<div class=\"ui-list-img\"><img img-src=\"{{ classRoom.middlePicture }}\" img-error=\"classroom\"> <span class=\"discount-label\" ng-class=\"classRoom.discount == 0 ? 'free' : 'rebate' \" ng-if=\"classRoom.discountId > 0\"><span class=\"discount-label-bottom\"></span> <span class=\"discount-label-content\" ng-if=\"classRoom.discount == 0\">限时<br>免费</span> <span class=\"discount-label-content\" ng-if=\"classRoom.discount > 0\">限时<br>打折</span></span></div><div class=\"ui-list-info\"><h2 class=\"ui-nowrap ui-list-title\">{{ classRoom.title }}</h2><p class=\"bottom price-body\"><span class=\"origin-price\" ng-if=\"! classRoom.priceType || classRoom.priceType == 'RMB' \">{{ classRoom.price | formatPrice }}</span> <span class=\"origin-price\" ng-if=\"classRoom.priceType == 'Coin' \">{{ classRoom.coinPrice | formatCoinPrice }} <small ng-if=\"classRoom.coinPrice > 0\">{{ classRoom.coinName }}</small></span></p><p class=\"price-body\">{{ classRoom.studentNum }}人在学</p></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/classroom_no_learn.html',
    "<div class=\"ui-course ui-classroom top-header ui-scroller\" style=\"padding-bottom: 58px;height:100%\"><div class=\"course-head-body\"><div class=\"course-head\"><img class=\"full-image\" ng-src=\"{{ classRoom.largePicture }}\" img-error=\"classroom\"></div></div><div class=\"ui-tab tab-top\" ui-tab height=\"auto\"><ul class=\"ui-tab-nav ui-border-tb\"><li><span>简介</span></li><li><span>轨迹</span></li><li><span>评价</span></li></ul><ul class=\"ui-tab-content tab-display\"><li ng-onload=\"loadClassRoomDetail()\"><div ng-include=\" 'view/classroom_detail.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/classroom_courses.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/classroom_review.html' | coverIncludePath \"></div></li></ul></div></div><div ng-controller=\"ClassRoomToolController\"><div class=\"ui-course-tool padding-s\" style=\"box-shadow: 0 0 2px rgba(0, 0, 0, 0.5)\"><button class=\"ui-btn btn-green\" ng-if=\"isCanShowConsultBtn()\" ng-class=\"'btn-col-45'\" ng-click=\"consultCourseTeacher()\"><i class=\"iconfont icon-0073dianhua01\"></i>咨询</button> <button class=\"ui-btn ml {{ getJoinBtnCls(classRoom.status) }}\" ng-click=\"joinClassroom()\">{{ classRoom.status != 'closed' ? '加入班级' : '班级已关闭' }}</button></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/classroom_review.html',
    "<div class=\"ui-course ui-course-review bg-light-white\" ng-controller=\"CourseReviewController\" ui-scroll data=\"reviews\" on-infinite=\"loadMore()\"><div class=\"bg-white\" ng-init=\"loadReviewResult('classroom', classRoom.id)\"><ul class=\"ui-grid-halve\"><li style=\"width:40%\"><div class=\"ui-list-info rating-body\"><h4 class=\"rating-num\">{{ reviewData.info.rating | number : 1 }}</h4><h4><i class=\"iconfont\" ng-class=\"(reviewData.info.rating | number : 0) > i ? 'icon-favorfill' : 'icon-favor' \" ng-repeat=\"i in 5 | array\"></i></h4><p>({{ reviewData.info.ratingNum }}份评分)</p></div></li><li style=\"width:60%\"><div class=\"ui-list-info\"><div class=\"rating-progress\" ng-repeat=\"n in reviewData.progress track by $index\"><span class=\"progress-title\"><i class=\"iconfont\" ng-class=\"$parent.$index + i < 5 ? 'icon-favorfill' : 'icon-favor' \" ng-repeat=\"i in 5 | array\"></i></span><div class=\"ui-progress ml\"><span style=\"width:{{ n | reviewProgress : reviewData.info.ratingNum }}\"></span></div></div></div></li></ul></div><div class=\"mt-x\"><section class=\"ui-panel ui-panel-card\"><h2 class=\"title-body\"><span class=\"title\">评价详情</span></h2><div class=\"ui-panel-content ui-review\"><ul class=\"ui-list\"><li class=\"ui-border-t\" ng-repeat=\"review in reviews\"><div class=\"ui-avatar\" ui-sref=\"userInfo({ userId : review.user.id })\"><img ng-src=\"{{ review.user.mediumAvatar | coverAvatar }}\" img-error=\"avatar\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap ui-review-header\"><a>{{ review.user.nickname }}</a> <a class=\"ui-review-rating\"><i class=\"iconfont\" ng-class=\"review.rating > i ? 'icon-favorfill' : 'icon-favor' \" ng-repeat=\"i in 5 | array\"></i></a> <a class=\"right font-xs\">{{ review.createdTime | coverArticleTime }}</a></h4><p class=\"ui-nowrap\">{{ review.content }}</p></div></li></ul></div></section></div><list-empty-view data=\"reviews\" title=\"暂时没有评价\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoad\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"close\"></button><h3 class=\"title\">课程详情</h3><div class=\"bar-tool\" ng-show=\"course && ! member\"><button ng-class=\"isFavorited ? 'color-red icon-heart' : 'icon-shoucang' \" class=\"ui-btn btn-outline iconfont\" ng-click=\"favoriteCourse()\"></button> <button class=\"ui-btn btn-outline iconfont icon-fenxiang\" ng-click=\"shardCourse()\"></button></div><div class=\"bar-tool\" ng-show=\"member && member.deadline != -1\"><div class=\"ui-pop\" ui-pop><button class=\"ui-btn btn-outline iconfont icon-xiazai\" ng-click=\"showDownLesson()\"></button> <button class=\"ui-btn btn-outline iconfont icon-shezhi\" ng-click=\"showCourseSetting()\"></button></div></div><div class=\"bar-tool\" ng-show=\"member && member.deadline == -1\"><div class=\"ui-pop\" ui-pop><button class=\"ui-btn btn-outline iconfont icon-shezhi\" ng-click=\"showCourseSetting()\"></button></div></div></div></div><div ng-include=\"courseView\" style=\"height:100%\"></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_detail.html',
    "<div class=\"bg-light-white\" ng-controller=\"CourseDetailController\"><section class=\"ui-panel ui-panel-card ui-border-t\" style=\"padding-right:0px;padding-bottom:16px\"><h2 class=\"title-body pr-x\" style=\"font-size: 18px\"><span class=\"title\">{{ course.title }}</span></h2><div class=\"ui-panel-content\" style=\"margin-top: 4px\"><span class=\"rating-body\" ng-if=\"! member\"><i class=\"iconfont\" ng-class=\"(course.rating | number : 0)  > i  ? 'icon-favorfill' : 'icon-favor' \" ng-repeat=\"i in ratingArray\"></i></span> <span class=\"rating-body\" style=\"top:1px;padding-left: 8px\" ng-if=\"! member\"><span class=\"price-block\">{{ course.originPrice | formatPrice }}</span></span> <span class=\"rating-body\" style=\"top:1px\" ng-show=\"shouldShowStudentNum == 1\">{{ course.studentNum }}名学生</span></div><ul class=\"ui-list list-link bottom ui-border-t mt\" ng-if=\"isCanShowVip(course.vipLevelId)\"><li style=\"line-height: 40px;margin-bottom: -12px\" ng-href=\"#/viplist\"><h4 class=\"ui-nowrap\"><i class=\"iconfont icon-favorfill color-red\"></i> 加入{{getVipTitle(course.vipLevelId)}}，免费学习大量课程</h4></li></ul></section><section class=\"ui-panel ui-panel-card\" ng-if=\"course.about\"><h2 class=\"title-body\"><span class=\"title\">课程简介</span></h2><div class=\"ui-panel-content mt content-style-filter\" ng-bind-html=\"course.about\" ng-img-show></div></section><section class=\"ui-panel ui-panel-card\" ng-if=\"goal\"><h2 class=\"title-body\"><span class=\"title\">课程目标</span></h2><div class=\"ui-panel-content mt\"><li ng-repeat=\"goal in course.goals track by $index\">{{ goal }}</li></div></section><section class=\"ui-panel ui-panel-card\" ng-if=\"course.audiences && course.audiences.length > 0\"><h2 class=\"title-body\"><span class=\"title\">适合人群</span></h2><div class=\"ui-panel-content mt\"><li ng-repeat=\"audience in course.audiences track by $index\">{{ audience }}</li></div></section><section class=\"ui-panel ui-panel-card\" style=\"margin-bottom:0\"><h2 class=\"title-body\"><span class=\"title\">讲师</span></h2><div class=\"ui-panel-content mt\"><ul class=\"ui-list ui-list-link\" style=\"margin-right: -16px\"><li class=\"ui-border-t\" ng-if=\"course.teachers[0]\" ui-sref=\"userInfo({ userId : course.teachers[0].id })\"><div class=\"ui-avatar-s\"><img ng-src=\"{{ course.teachers[0].avatar | coverAvatar }}\" img-error=\"avatar\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\">{{ course.teachers[0].nickname }}</h4><p class=\"ui-nowrap\">{{ course.teachers[0].title }}</p></div></li><li ng-if=\"! course.teachers[0]\"><p>该课程暂无教师</p></li></ul></div></section></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_discuss.html',
    "<ul class=\"ui-list list-link ui-discuss\" style=\"margin-bottom: 40px\" ng-controller=\"CourseDiscussController\" ng-init=\"initThreads()\"><li class=\"ui-border-b padding-x\" ng-repeat=\"thread in threads\" ng-click=\"showThread(thread)\"><div class=\"ui-list-info\" style=\"margin-bottom: -10px\"><h4 class=\"ui-nowrap\"><span ng-if=\"thread.type == 'question' \" class=\"label-x color-yellow font-s\">问答</span> <span ng-if=\"thread.type == 'discussion' \" class=\"label-x color-blue font-s\">话题</span> <span style=\"font-size: 15px; font-weight: 500\">{{ thread.title }}</span></h4><p class=\"ui-nowrap-multi mt font-n\" style=\"color: #000000; font-size: 12px !important\">{{ thread.content }}</p><ul class=\"ui-list inner mt\"><li class=\"ui-border-t\"><div class=\"ui-avatar-s xxs\"><img ng-src=\"{{thread.user.avatar}}\" img-error=\"avatar\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap ui-review-header font-s color-gray\">{{ thread.user.nickname }} <span>{{ thread.latestPostTime }}</span></h4></div></li></ul></div></li><list-empty-view class=\"lesson-empty\" data=\"threads\" title=\"暂无课程讨论\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"loading\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></ul>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_learn.html',
    "<div class=\"ui-course top-header ui-scroller\" style=\"padding-bottom: 10px\"><div class=\"course-head-body\"><div class=\"course-head\"><img class=\"full-image\" ng-src=\"{{ course.largePicture }}\" img-error=\"course\"></div></div><div id=\"nav\" class=\"ui-tab tab-top\" ui-tab height=\"auto\"><ul class=\"ui-tab-nav ui-border-tb\"><li><span>简介</span></li><li><span>课时</span></li><li><span>讨论</span></li></ul><ul class=\"ui-tab-content tab-display\"><li><div ng-include=\" 'view/course_detail.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/course_lesson.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/course_discuss.html' | coverIncludePath \"></div></li></ul></div></div><div ng-controller=\"CourseToolController\"><div ng-show=\"!currentPage || currentPage < 2\"><div class=\"ui-course-tool bg-yellow color-white font-x\" ng-click=\"continueLearnCourse()\" style=\"box-shadow: 0 0 2px rgba(0, 0, 0, 0.5)\" ng-if=\"lastIndex <= 0\"><i class=\"iconfont icon-shuben mr\"></i> <span>已加入、开始学习</span></div><div class=\"ui-course-tool bg-green color-white font-x\" ng-click=\"continueLearnCourse()\" style=\"box-shadow: 0 0 2px rgba(0, 0, 0, 0.5)\" ng-if=\"lastIndex > 0\"><i class=\"iconfont icon-lessonvideo mr\"></i> <span>已学到第{{ lastIndex }}课时，继续学习</span></div><div class=\"ui-course-tool bg-green color-white font-x\" ng-click=\"continueLearnCourse()\" style=\"box-shadow: 0 0 2px rgba(0, 0, 0, 0.5)\" ng-if=\"member.isLearned == 1\"><i class=\"iconfont icon-lessonvideo mr\"></i> <span>课程已学习完成</span></div></div><div ng-show=\"currentPage == 2\"><div class=\"ui-course-tool color-white font-x padding-s\" style=\"box-shadow: 0 0 2px rgba(0, 0, 0, 0.5)\"><button class=\"ui-btn btn-yellow btn-col-45\" ng-click=\"postQuestion('course', course.id)\"><i class=\"iconfont icon-question\"></i>提问题</button> <button class=\"ui-btn btn-blue btn-col-45 ml\" ng-click=\"postQuestion('course', course.id, 'discussion')\"><i class=\"iconfont icon-message\"></i>发话题</button></div></div></div><script type=\"text/javascript\" src=\"js/scrollEffect.js\"></script><script type=\"text/javascript\">window.onload = function () {\r" +
    "\n" +
    "        navScollTopFixed(nav);\r" +
    "\n" +
    "    }</script>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_lesson.html',
    "<div class=\"ui-lesson\" style=\"margin-bottom: 20px\"><ul class=\"ui-list ui-list-lesson\" style=\"padding-right:0px\" ng-controller=\"CourseLessonController\"><li class=\"{{ lesson.type }} ui-border-b\" ng-repeat=\"lesson in lessons\" ng-class=\"lesson.id == lastLearnStatusIndex ? 'color-green' : 'color-black' \" ng-click=\"learnLesson(lesson)\"><span class=\"icon-center\"><i class=\"iconfont mr-s\" ng-class=\" lesson | lessonIcon\" ng-if=\"lesson.type !='chapter' && lesson.type !='unit' \"></i></span><div class=\"ui-list-info ui-nowrap\" ng-class=\"lesson.type\"><span class=\"\">{{ lesson | formatChapterNumber }} {{ lesson.title }}</span></div><span ng-bind-html=\"learnStatuses[lesson.id] | lessonLearnStatusTag : lesson.type\" class=\"ml\" style=\"margin-right: -8px\"></span> <span ng-bind-html=\"lesson | lessonType\" class=\"ml\"></span> <span class=\"color-light-gray\" style=\"margin-right: 20px\"><span ng-if=\"lesson.type !='chapter' && lesson.type !='unit' \">{{ lesson.length }}</span></span></li><list-empty-view class=\"lesson-empty\" data=\"lessons\" title=\"暂无课时\"></list-empty-view><list-empty-view ng-if=\"errorMsg\" class=\"lesson-empty\" data=\"[]\" title=\"{{ errorMsg }}\"></list-empty-view><div ng-if=\"! errorMsg\" class=\"ui-loading-wrap\" ng-show=\"loading\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></ul></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_list.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">分类搜索</h3></div></div><div class=\"ui-tab tab-top ui-courselist\" ui-tab select=\"empty\"><ul class=\"ui-tab-nav ui-border-b\"><li><span class=\"line\"><label>{{ categoryTab.category }}</label><i class=\"iconfont icon-keyboardarrowdown\"></i></span></li><li><span class=\"line\"><label>{{ categoryTab.type }}</label><i class=\"iconfont icon-keyboardarrowdown\"></i></span></li><li><span class=\"line\"><label>{{ categoryTab.sort }}</label><i class=\"iconfont icon-keyboardarrowdown\"></i></span></li></ul><div class=\"ui-tab-content tab-display top-tab-header\" style=\"position: fixed\"><li modal><div class=\"content category-card\"><category-tree ng-if=\"categoryTree\" data=\"categoryTree\" listener=\"categorySelectedListener\"></category-tree></div><div class=\"backdrop-bg\"></div></li><li modal><div class=\"content\"><ul class=\"ui-list ui-list-text ui-list-cover ui-list-active\"><li class=\"ui-border-b\" ng-click=\"selectType(item)\" ng-repeat=\"item in courseListTypes\">{{ item.name }}</li></ul></div><div class=\"backdrop-bg\"></div></li><li modal><div class=\"content\"><ul class=\"ui-list ui-list-text ui-list-cover ui-list-active\"><li class=\"ui-border-b\" ng-click=\"selectSort(item)\" ng-repeat=\"item in courseListSorts\">{{ item.name }}</li></ul></div><div class=\"backdrop-bg\"></div></li></div><div class=\"ui-scroller course-card\" ui-scroll data=\"courses\" on-infinite=\"loadMore(successCallback)\"><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"course in courses\" ng-click=\"gotoNativeDetailCoursePage(course.id)\" ng-include=\" 'view/course_list_item.html' | coverIncludePath \"></li></ul><list-empty-view data=\"courses\" title=\"暂时没有课程\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoad\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_list_item.html',
    "<div class=\"ui-list-img\"><img ng-src=\"{{ course.middlePicture }}\" img-error=\"course\"> <span class=\"discount-label\" ng-class=\"course.discount == 0 ? 'free' : 'rebate' \" ng-if=\"course.discountId > 0\"><span class=\"discount-label-bottom\"></span> <span class=\"discount-label-content\" ng-if=\"course.discount == 0\">限时<br>免费</span> <span class=\"discount-label-content\" ng-if=\"course.discount > 0\">限时<br>打折</span></span></div><div class=\"ui-list-info\"><h2 class=\"ui-nowrap ui-list-title\">{{ course.title }}</h2><p class=\"bottom price-body\"><span class=\"origin-price\" ng-if=\"! course.priceType || course.priceType == 'RMB' \">{{ course.price | formatPrice }} <s class=\"discount-color\" ng-if=\"course.discountId > 0\">{{ course.originPrice | formatPrice }}</s></span> <span class=\"origin-price\" ng-if=\"course.priceType == 'Coin' \">{{ course.price | formatCoinPrice }} <small ng-if=\"course.price > 0\">{{ course.coinName }}</small> <s class=\"discount-color\" ng-if=\"course.discountId > 0\">{{ course.originPrice | formatPrice }}</s></span> <span class=\"right\"><!-- <i class=\"iconfont icon-person\"></i> -->{{ course.studentNum }}人在学</span></p></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_no_learn.html',
    "<div class=\"ui-course top-header ui-scroller\" style=\"padding-bottom: 10px\"><div class=\"course-head-body\"><div class=\"course-head\"><img class=\"full-image\" ng-src=\"{{ course.largePicture }}\" img-error=\"course\"></div></div><div id=\"stickyNavi\" class=\"ui-tab tab-top\" ui-tab height=\"auto\"><ul class=\"ui-tab-nav ui-border-tb\"><li><span>简介</span></li><li><span>课时</span></li><li><span>评价</span></li></ul><ul class=\"ui-tab-content tab-display\"><li><div ng-include=\" 'view/course_detail.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/course_lesson.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/course_review.html' | coverIncludePath \"></div></li></ul></div></div><div ng-if=\"0 == course.parentId\" ng-controller=\"CourseToolController\"><div class=\"ui-course-tool padding-s\" style=\"box-shadow: 0 0 2px rgba(0, 0, 0, 0.5)\"><button class=\"ui-btn btn-green\" ng-if=\"isCanShowConsultBtn()\" ng-class=\"'btn-col-45'\" ng-click=\"consultCourseTeacher()\"><i class=\"iconfont icon-0073dianhua01\"></i>咨询</button> <button class=\"ui-btn ml {{ getJoinBtnCls(course.status) }}\" ng-click=\"joinCourse()\">{{ joinButtonTitle() }}</button></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_notice.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">{{ titleType }}公告</h3></div></div><div class=\"top-header ui-course-notice\" ng-init=\"loadMore()\"><ul class=\"ui-list ui-border-b\"><li class=\"ui-border-b\" ng-repeat=\"notice in notices\"><div class=\"ui-avatar\"><span class=\"notice-icon\"><i class=\"iconfont icon-gonggao\"></i></span></div><div class=\"ui-list-info\"><h4>公告</h4><p class=\"notice-content\" ng-bind-html=\"notice.content\"></p></div></li></ul><list-empty-view data=\"notices\" title=\"暂时没有{{ titleType }}公告\"></list-empty-view><div class=\"ui-tips ui-tips-info\" ng-click=\"loadMore()\" ng-show=\"showLoadMore\"><p>查看更早公告...</p></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_pay.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">确认订单</h3></div></div><div class=\"top-header ui-course-pay\"><!-- \t<div class=\"ui-form ui-border-t\">\r" +
    "\n" +
    "\t        <div class=\"ui-form-item ui-border-b ui-list-divider\">\r" +
    "\n" +
    "\t            确认个人信息\r" +
    "\n" +
    "\t        </div>\r" +
    "\n" +
    "\t        <div class=\"ui-form-item ui-border-b\">\r" +
    "\n" +
    "\t            <label>\r" +
    "\n" +
    "\t                姓名\r" +
    "\n" +
    "\t            </label>\r" +
    "\n" +
    "\t            <input type=\"text\" placeholder=\"{{ data.userProfile.truename ? '' : '还没填写真实姓名' }}\" ng-model=\"data.userProfile.truename\" readonly>\r" +
    "\n" +
    "\t        </div>\r" +
    "\n" +
    "\t        <div class=\"ui-form-item ui-border-b\">\r" +
    "\n" +
    "\t            <label>\r" +
    "\n" +
    "\t                手机\r" +
    "\n" +
    "\t            </label>\r" +
    "\n" +
    "\t            <input type=\"text\" placeholder=\"{{ data.userProfile.mobile ? '' : '还没填写手机号码' }}\" ng-model=\"data.userProfile.mobile\" readonly>\r" +
    "\n" +
    "\t        </div>\r" +
    "\n" +
    "\t</div> --><ul class=\"ui-list ui-list-text ui-border-b ui-paycard\"><li class=\"ui-border-t ui-list-divider\">{{ orderLabel }}</li><li class=\"ui-border-t\"><div class=\"ui-list-img\"><img ng-src=\"{{ data.orderInfo.picture }}\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\">{{ data.orderInfo.title }}</h4><p class=\"pay-price\" ng-if=\"data.coin\">{{ data.orderInfo.price * data.coin.cashRate | formatPrice }}</p><p class=\"pay-price\" ng-if=\"! data.coin\">{{ data.orderInfo.price | formatPrice }}</p></div></li></ul><ul class=\"ui-list ui-list-link ui-list-text ui-border-b\"><li class=\"ui-border-t ui-list-divider\">优惠信息</li><li class=\"ui-border-t\" ng-click=\"selectCoupon()\" ng-if=\"isShowCoupon()\"><h4 class=\"ui-nowrap\">优惠 <span class=\"pay-price\" ng-if=\"coupon\">{{ coupon.type == 'discount' ? '打折' : '抵价' }} {{ coupon.rate }}</span></h4></li></ul><ul class=\"ui-list ui-list-text ui-border-b\" ng-if=\"coin\"><li class=\"ui-border-t\"><div class=\"ui-list-info\"><h4>使用{{ coin.name }} <span class=\"subtitle\">汇率{{ coin.cashRate }}</span></h4></div><label class=\"ui-switch\" ng-if=\"!checkIsCoinMode()\"><input type=\"checkbox\" ng-model=\"payMode\" ng-change=\"changePayMode()\" ng-checked=\"payMode == 'coin' \" ng-if=\"priceType != 'Coin'\"></label></li></ul><div class=\"ui-btn-wrap\" style=\"background: #f0f0f0\"><div class=\"pay-body\">需支付:<p class=\"pay-price\">{{ payPrice | formatPrice }} <span>{{ payMode == 'coin' ? coin.name : '' }}</span></p></div><button class=\"ui-btn-lg btn-yellow\" ng-click=\"pay()\">去支付</button></div></div><div class=\"ui-dialog ui-coupon full\"><div class=\"ui-dialog-bg\"><div class=\"ui-dialog-bgcontent\"></div></div><div class=\"ui-dialog-cnt\"><div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"close\"></button><h3 class=\"title\">优惠码</h3><button class=\"ui-btn bar-tool btn-outline small\" ng-click=\"checkCoupon()\">确认</button></div></div><div class=\"ui-form ui-border-t\"><div class=\"ui-form-item ui-border-b ui-list-divider\">填写优惠信息</div><div class=\"ui-form-item ui-border-b\"><label>优惠码</label><input type=\"text\" placeholder=\"优惠码\" ng-model=\"formData.code\"> <a class=\"ui-icon-close\" ng-show=\"formData.code.length > 0\" ng-click=\"formData.code = '' \"></a></div><div class=\"ui-form-item ui-list-divider item-error\">{{ formData.error }}</div></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_review.html',
    "<div class=\"ui-course ui-course-review bg-light-white\" data=\"reviews\" on-infinite=\"loadMore()\" ng-controller=\"CourseReviewController\"><div class=\"bg-white\" ng-init=\"loadReviewResult('course', course.id)\"><ul class=\"ui-grid-halve\"><li style=\"width:40%\"><div class=\"ui-list-info rating-body\" style=\"margin-top: 8px\"><h4 class=\"rating-num\">{{ reviewData.info.rating | number : 1}}</h4><h4><i id=\"{{i}}\" class=\"iconfont\" ng-class=\"(reviewData.info.rating | number : 0) > i  ? 'icon-favorfill' : 'icon-favor' \" ng-repeat=\"i in 5 | array\"></i></h4><p>({{ reviewData.info.ratingNum }}份评分)</p></div></li><li style=\"width:60%\"><div class=\"ui-list-info\" style=\"width: 260px;margin-left: -30px\"><div class=\"rating-progress\" ng-repeat=\"n in reviewData.progress track by $index\"><span class=\"progress-title\"><i class=\"iconfont\" ng-class=\" $parent.$index + i < 5  ? 'icon-favorfill' : 'icon-favor' \" ng-repeat=\"i in 5 | array\"></i></span><div class=\"ui-progress ml\"><span style=\"width:{{ n | reviewProgress : reviewData.info.ratingNum }}\"></span></div></div></div></li></ul></div><div class=\"mt-x bg-white\" style=\"margin-bottom: -20px\"><section class=\"ui-panel ui-panel-card\" style=\"padding-right: 0px\"><h2 class=\"title-body\"><span class=\"title\">评价详情</span></h2><div class=\"ui-panel-content ui-review\"><ul class=\"ui-list\"><li class=\"ui-border-t\" ng-repeat=\"review in reviews\"><div class=\"ui-avatar\" ui-sref=\"userInfo({ userId : review.user.id })\" style=\"height: 40px; width: 40px\"><img ng-src=\"{{ review.user.mediumAvatar | coverAvatar }}\" img-error=\"avatar\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap ui-review-header\"><a>{{ review.user.nickname }}</a> <a class=\"ui-review-rating\"><i class=\"iconfont\" ng-class=\"review.rating > i ? 'icon-favorfill' : 'icon-favor' \" ng-repeat=\"i in 5 | array\"></i></a> <a class=\"right font-s\">{{ review.createdTime | coverArticleTime }}</a></h4><p class=\"ui-nowrap-multi color-gray\" style=\"min-height:22px\">{{ review.content }}</p></div></li></ul></div></section></div><list-empty-view data=\"reviews\" title=\"暂时没有评价\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoad\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/course_setting.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">课程设置</h3></div></div><div class=\"top-header\"><div class=\"ui-form ui-border-t\"><div class=\"ui-form-item ui-form-item-switch ui-border-b\"><p>讨论组消息免打扰</p><label class=\"ui-switch\"><input type=\"checkbox\"></label></div><div class=\"ui-form-item ui-form-item-switch ui-border-b\"><p>课程消息免打扰</p><label class=\"ui-switch\"><input type=\"checkbox\"></label></div><div class=\"ui-form-item ui-form-item-switch\"><div ng-if=\"isLearn\" class=\"ui-btn-wrap sign-padding\"><button class=\"ui-btn-lg btn-red\" ng-click=\"exitLearnCourse()\">退出课程</button></div></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/courselist_modal.html',
    "<div class=\"modal courselist-modal\"><ion-tabs class=\"tabs-green tabs-top tabs-background-positive tabs-color-light\"><div class=\"splice-line\"></div><ion-tab title=\"全部分类\"><ion-nav-view name=\"courselist-type\"><ion-view><ion-content class=\"courselist-content\"><div class=\"list\"><a class=\"item\" ng-click=\"selectType(item.type)\" ng-repeat=\"item in courseListTypes\">{{ item.name }}</a></div></ion-content></ion-view></ion-nav-view></ion-tab><ion-tab title=\"综合排序\"><ion-nav-view name=\"courselist-sort\"><ion-view><ion-content class=\"courselist-content\"><div class=\"list\"><a class=\"item\" ng-click=\"selectSort(item.type)\" ng-repeat=\"item in courseListSorts\">{{ item.name }}</a></div></ion-content></ion-view></ion-nav-view></ion-tab></ion-tabs></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/courselist_sort.html',
    "<ion-view><ion-content class=\"padding\"><div class=\"list\"><a class=\"item\" ng-click=\"selectCategory(item)\" ng-repeat=\"item in courseListSorts\">{{ item }}</a></div></ion-content></ion-view>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/courselist_type.html',
    "<ion-view><ion-content class=\"padding\"><div class=\"list\"><a class=\"item\" ng-click=\"selectCategory(item)\" ng-repeat=\"item in courseListTypes\">{{ item }}</a></div></ion-content></ion-view>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/found.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-menu\" ng-click=\"toggle()\"></button><h3 class=\"title\" ng-click=\"openModal()\">发现</h3><button class=\"ui-btn bar-tool btn-outline iconfont icon-sousuo\"></button></div></div><div class=\"ui-tab tab-top\" ui-tab><ul class=\"ui-tab-nav ui-border-b\"><li><span class=\"line\">课程</span></li><li><span>直播</span></li></ul><ul class=\"ui-tab-content tab-display\"><li><div ui-view=\"found-course\"></div></li><li><div ui-view=\"found-live\"></div></li></ul></div><div class=\"ui-dialog full\"><div class=\"ui-dialog-bg\"><div class=\"ui-dialog-bgcontent\"></div></div><div class=\"ui-dialog-cnt\"><div class=\"ui-dialog-bd category-card\"><category-tree data=\"categoryTree\" listener=\"categorySelectedListener\"></category-tree></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/found_classroom.html',
    "<div class=\"top-tab-header ui-found-course\" ng-controller=\"FoundClassRoomController\"><div class=\"course-card classroom-card\"><h4><span class=\"circle-label\"></span>推荐</h4><list-empty-view data=\"recommendClassRooms\" title=\"暂时没有推荐班级\"></list-empty-view><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"classRoom in recommendClassRooms\" ng-href=\"#/classroom/{{ classRoom.id  }}\" ng-include=\" 'view/classroom_list_item.html' | coverIncludePath \"></li></ul><div class=\"ui-btn-group\" ng-if=\"recommendClassRooms.length > 0\"><button type=\"button\" class=\"btn-green\" ng-href=\"#/classroomlist/\">更多</button></div></div><div class=\"course-card classroom-card\"><h4><span class=\"circle-label\"></span>最新</h4><list-empty-view data=\"latestClassrooms\" title=\"暂时没有最新班级\"></list-empty-view><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"classRoom in latestClassrooms\" ng-href=\"#/classroom/{{ classRoom.id  }}\" ng-include=\" 'view/classroom_list_item.html' | coverIncludePath \"></li></ul><div class=\"ui-btn-group\" ng-if=\"latestClassrooms.length > 0\"><button type=\"button\" class=\"btn-green\" ng-href=\"#/classroomlist/\">更多</button></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/found_course.html',
    "<div class=\"top-tab-header ui-found-course\" ng-controller=\"FoundCourseController\"><div class=\"ui-slider course-slider\" slider=\"course-slider\" ui-slider-box=\"banners\"><ul class=\"ui-slider-content\"><li ng-repeat=\"banner in banners\" ng-click=\"bannerClick(banner)\"><span style=\"background-image:url({{ banner.url }})\"></span></li></ul></div><div class=\"course-card\"><h4><span class=\"circle-label\"></span>推荐</h4><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"course in recommedCourses\" ng-href=\"#/course/{{ course.id  }}\" ng-include=\" 'view/course_list_item.html' | coverIncludePath \"></li></ul><div class=\"ui-btn-group\" ng-if=\"recommedCourses.length > 0\"><button type=\"button\" class=\"btn-green\" ng-href=\"#/courselist/normal/\">更多</button></div></div><div class=\"course-card\"><h4><span class=\"circle-label\"></span>最新</h4><list-empty-view data=\"latestCourses\" title=\"暂时没有最新课程\"></list-empty-view><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"course in latestCourses\" ng-href=\"#/course/{{ course.id  }}\" ng-include=\" 'view/course_list_item.html' | coverIncludePath \"></li></ul><div class=\"ui-btn-group\" ng-if=\"latestCourses.length > 0\"><button type=\"button\" class=\"btn-green\" ng-href=\"#/courselist/normal/\">更多</button></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/found_live.html',
    "<div class=\"top-tab-header ui-found-course\" ng-controller=\"FoundLiveController\"><div class=\"course-card\"><h4><span class=\"circle-label\"></span>推荐</h4><list-empty-view data=\"liveRecommedCourses\" title=\"暂时没有推荐直播课程\"></list-empty-view><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"course in liveRecommedCourses\" ng-href=\"#/course/{{ course.id  }}\" ng-include=\" 'view/course_list_item.html' | coverIncludePath \"></li></ul><div class=\"ui-btn-group\" ng-if=\"liveRecommedCourses.length > 0\"><button type=\"button\" class=\"btn-green\" ng-href=\"#/courselist/live/\">更多</button></div></div><div class=\"course-card\"><h4><span class=\"circle-label\"></span>最新</h4><list-empty-view data=\"liveLatestCourses\" title=\"暂时没有最新直播课程\"></list-empty-view><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"course in liveLatestCourses\" ng-href=\"#/course/{{ course.id  }}\" ng-include=\" 'view/course_list_item.html' | coverIncludePath \"></li></ul><div class=\"ui-btn-group\" ng-if=\"liveLatestCourses.length > 0\"><button type=\"button\" class=\"btn-green\" ng-href=\"#/courselist/live/\">更多</button></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/homework_check.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">作业批改</h3></div></div><div class=\"top-header ui-homework\" ng-init=\"loadHomeworkResult()\"><section class=\"ui-panel\"><div class=\"ui-header\">作业题目 <span class=\"label\"><label ng-bind=\"currentQuestionIndex\"></label>/{{ items.length }}</span></div><div class=\"ui-slider homework-slider\" slider=\"homework-slider\" ui-slider-box=\"items\" scroll-change=\"questionItemChange()\"><ul class=\"ui-slider-content\"><li ng-repeat=\"item in items\"><div class=\"question-container\"><h4 class=\"header\"><span ng-bind=\"getItemStem($index, item.type)\"></span> <span ng-bind-html=\"item.stem\"></span></h4><div ng-include=\" getItemView(item) | coverIncludePath \"></div></div></li></ul></div></section></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/homework_choice_view.html',
    "<div class=\"ui-choice\"><ul><li ng-repeat=\"meta in item.metas track by $index\" ng-class=\"item.answer | fillAnswer : $index\"><span class=\"item\" ng-bind=\"getItemIndex(item, $index)\"></span><label class=\"body\" ng-bind-html=\"meta\"></label></li></ul><ul class=\"ui-grid-halve ui-answer\"><li><span class=\"answer-status-label success\" ng-class=\"item.result.status | questionResultStatusColor\"><i class=\"iconfont\" ng-class=\"item.result.status | questionResultStatusIcon\"></i></span></li><li><span>正确答案<label class=\"primary\" ng-bind=\"getItemAnswer(item)\"></label></span> <span>学员答案<label class=\"wrong\" ng-bind=\"getResultAnswer(item)\"></label></span></li></ul></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/homework_determine_view.html',
    "<div class=\"ui-determine\"><ul class=\"ui-grid-halve ui-answer\"><li class=\"primary\"><i class=\"iconfont icon-duigou\"></i></li><li class=\"wrong\"><i class=\"iconfont icon-wrong\"></i></li></ul></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/homework_essay_view.html',
    "<div class=\"ui-essay\"><div class=\"body\"><p class=\"result\" ng-bind-html=\"getResultAnswer(item)\"></p></div><div class=\"success-result ui-border-t\"><h4>参考答案</h4><p ng-bind-html=\"getItemAnswer(item)\"></p></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/homework_fill_view.html',
    "<div class=\"ui-fill\"><ul><li ng-repeat=\"meta in getFillQuestionItem(item)\"><span class=\"body\" ng-bind-html=\"meta\"></span></li></ul><ul class=\"ui-grid-halve ui-answer\"><li><span class=\"answer-status-label success\" ng-class=\"item.result.status | questionResultStatusColor\"><i class=\"iconfont\" ng-class=\"item.result.status | questionResultStatusIcon\"></i></span></li><li><span>正确答案<label class=\"primary\" ng-bind=\"getItemAnswer(item)\"></label></span> <span>学员答案<label class=\"wrong\" ng-bind=\"getResultAnswer(item)\"></label></span></li></ul></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/lesson.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">{{ lesson.title }}</h3></div></div><div class=\"top-header ui-lesson\"><div ng-include=\"lessonView\"></div></div><script type=\"text/ng-template\" id=\"view/lesson_text.html\"><div class=\"lesson-content\" ng-html=\"lesson.content\" ng-img-show></div></script>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/login.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">登 录</h3><a class=\"ui-btn btn-outline bar-tool small\" href=\"#/regist\">注册</a></div></div><div class=\"top-header sign login\"><div class=\"ui-form\"><form action=\"#\"><div class=\"ui-form-item ui-form-item-pure ui-border-b\"><input type=\"text\" placeholder=\"手机号/邮箱/昵称\" ng-model=\"user.username\"> <a class=\"ui-icon-close\" ng-show=\"user.username.length > 0\" ng-click=\"user.username = '' \"></a></div><div class=\"ui-form-item ui-form-item-pure ui-border-b margin-t\"><input type=\"password\" placeholder=\"密码\" ng-model=\"user.password\"> <a class=\"ui-icon-close\" ng-show=\"user.password.length > 0\" ng-click=\"user.password = '' \"></a></div></form><div class=\"ui-btn-wrap padding-none margin-t\"><button class=\"ui-btn-lg btn-green\" ng-click=\"login(user)\">登 录</button></div></div><div style=\"margin-top:16px;text-align: center\"><div class=\"shard-label\"><span>| 其他方式登录 |</span></div><ul class=\"{{getThirdStyle()}}\" ng-if=\"thirdConfig.length > 0\"><li ng-if=\"hasThirdType('QQ')\"><i class=\"iconfont icon-qq shard-login qq-login\" ng-click=\"loginWithOpen('QQ')\"></i></li><li ng-if=\"hasThirdType('SinaWeibo')\"><i class=\"iconfont icon-icon shard-login weibo-login\" ng-click=\"loginWithOpen('SinaWeibo')\"></i></li><li ng-if=\"hasThirdType('Wechat')\"><i class=\"iconfont icon-weixin shard-login weixin-login\" ng-click=\"loginWithOpen('Wechat')\"></i></li></ul></div><div class=\"ui-btn-group\" ng-if=\"!platform.android\"><button class=\"ui-btn more-btn btn-outline\" ng-click=\"jumpToSetting()\">更 多</button></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/main.html',
    "<div side-view class=\"side-content\"><div id=\"st-container\" class=\"st-container\"><nav class=\"st-menu st-effect-1 menu-content\" id=\"menu-1\"><ul class=\"ui-list ui-list-text ui-list-avatar\"><li class=\"ui-border-t\" ng-click=\"showMyView('userinfo')\"><div class=\"ui-avatar-one\"><img ng-src=\"{{ user.mediumAvatar | coverAvatar }}\"></div><div class=\"ui-list-info ui-border-t\" ng-if=\"user\"><h3>{{ user.nickname }}</h3><p class=\"ui-nowrap\">{{ user.signature ? user.signature : '神马都没有' }}</p></div><div class=\"ui-list-info ui-border-t\" ng-if=\"!user\"><h3>个人中心</h3><p>登录/注册</p></div></li></ul><div ng-if=\"! user\"><div class=\"ui-btn-wrap\"><a class=\"ui-btn-lg btn-green\" ng-click=\"showMyView('login')\">登 录</a></div><div class=\"ui-btn-wrap\"><a class=\"ui-btn-lg btn-black\" href=\"#/regist\">注 册</a></div></div><ul class=\"ui-list ui-list-text\" ng-if=\"user\"><li class=\"ui-border-t\" ng-click=\"showMyView('mylearn')\"><i class=\"icon iconfont icon-shuben\"></i> 我的学习</li><li class=\"ui-border-t\" ui-sref=\"viplist()\"><i class=\"icon iconfont icon-huizhang\"></i> 开通会员</li><li class=\"ui-border-t\" ng-click=\"showMyView('myfavorite')\"><i class=\"icon iconfont icon-shoucang\"></i> 我的收藏</li><li class=\"ui-border-t\" ng-click=\"showMyView('mygroup')\"><i class=\"icon iconfont icon-fabiao\"></i> 我的发表</li><li class=\"ui-border-t\" ng-click=\"showMyView('setting')\"><i class=\"icon iconfont icon-shezhi\"></i> 设置</li></ul></nav><div class=\"st-content\"><div class=\"st-pusher\"></div><div ui-view=\"menuContent\"></div></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/main_content.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button ng-if=\"!platform.native\" class=\"ui-btn btn-outline iconfont icon-menu\" ng-click=\"toggle()\"></button><h3 class=\"title\">发现</h3><button class=\"ui-btn bar-tool btn-outline iconfont icon-sousuo\" ng-href=\"#/search\"></button></div></div><div class=\"ui-tab tab-top\" ui-tab><ul class=\"ui-tab-nav ui-border-b\"><li><span class=\"line\">课程</span></li><li><span class=\"line\">直播</span></li><li><span>班级</span></li></ul><ul class=\"ui-tab-content ui-scroller tab-display\"><li><div ng-include=\" 'view/found_course.html' | coverIncludePath \"></div></li><li ng-onload=\"loadPage('live')\"><div ng-include=\"live | coverIncludePath\"></div></li><li ng-onload=\"loadPage('classroom')\"><div ng-include=\"classroom | coverIncludePath \"></div></li></ul></div><div class=\"ui-dialog full\"><div class=\"ui-dialog-bg\"><div class=\"ui-dialog-bgcontent\"></div></div><div class=\"ui-dialog-cnt\"><div class=\"ui-dialog-bd category-card\"><category-tree data=\"categoryTree\" listener=\"categorySelectedListener\"></category-tree></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/menu_view.html',
    "<ion-side-menus><ion-side-menu-content><ion-nav-view name=\"menuContent\"></ion-nav-view></ion-side-menu-content><ion-side-menu side=\"left\"><ion-content><ul class=\"list\"><a class=\"item item-avatar\" ng-click=\"showUserInfo()\"><img ng-src=\"{{ user.mediumAvatar | coverAvatar }}\"><h3>{{ user.nickname }}</h3><p>{{ user.nickname }}</p></a> <a class=\"item item-icon-left\" menu-toggle=\"left\" ng-click=\"showMyLearn()\"><i class=\"icon iconfont icon-school\"></i> 我的学习</a> <a class=\"item item-icon-left\" menu-toggle=\"left\" ng-click=\"showMyFavorite()\"><i class=\"icon iconfont icon-search\"></i> 我的收藏</a> <a class=\"item item-icon-left\" menu-toggle=\"left\" ng-click=\"showMyGroup()\"><i class=\"icon iconfont icon-send\"></i> 我的发表</a> <a class=\"item item-icon-left\" hmenu-toggle=\"left\"><i class=\"icon iconfont icon-setting\"></i> 设置</a></ul></ion-content></ion-side-menu></ion-side-menus>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/modify_userinfo.html',
    "<div class=\"ui-dialog ui-coupon full\"><div class=\"ui-dialog-bg\"><div class=\"ui-dialog-bgcontent\"></div></div><div class=\"ui-dialog-cnt\"><div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"close\"></button><h3 class=\"title\">加入学习</h3><button class=\"ui-btn bar-tool btn-outline small\" ng-click=\"updateModifyInfo()\">确认</button></div></div><div class=\"ui-form ui-border-t\"><div class=\"ui-form-item ui-border-b ui-list-divider\">温情提示：请填写相关认证资料</div><div class=\"ui-form-item ui-border-b\" ng-repeat=\"modifyInfo in modifyInfos\"><label>{{ modifyInfo.title }}</label><input type=\"text\" ng-model=\"modifyInfo.content\" placeholder=\"{{ modifyInfo.title }}\"> <a class=\"ui-icon-close\" ng-click=\"modifyInfo.content = '' \"></a></div></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/my_subscribe.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">我的预约</h3></div></div><div class=\"\"><div class=\"ui-tab tab-top ui-scroller\" ui-tab select=\"0\"><ul class=\"ui-tab-nav ui-border-tb\"><li><span class=\"line\">我发布的</span></li><li><span>我抢到的</span></li></ul><ul class=\"ui-tab-content tab-display\" style=\"margin-top:90px\"><li><table class=\"ui-table ui-border-tb\"><thead><tr><th>预约内容</th><th>开始时间</th><th>预约</th><th>发布</th><th>总价</th></tr></thead><tbody><tr><td>2014257777</td><td>开始时间</td><td>2016-02-06</td><td>2016-02-06</td><td>2016-02-06</td></tr></tbody></table></li><li><div ng-include=\" 'view/course_lesson.html' | coverIncludePath \"></div></li></ul></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/myfavorite.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">我的收藏</h3></div></div><div class=\"ui-tab tab-top ui-scroller ui-courselist\" ui-tab><ul class=\"ui-tab-nav ui-border-b\"><li><span class=\"line\">课程</span></li><li><span>直播课</span></li></ul><ul class=\"ui-tab-content tab-display ui-course-learn\"><li><div ng-include=\" 'view/myfavorite_course.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/myfavorite_live.html' | coverIncludePath \"></div></li></ul></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/myfavorite_course.html',
    "<div class=\"ui-scroller course-card\" ng-controller=\"MyFavoriteCourseController\"><ul class=\"ui-list\"><li class=\"ui-list-avatar ui-border-t\" ng-repeat=\"course in data.course.data\" ng-click=\"gotoNativeDetailCoursePage(course.id)\"><div class=\"ui-list-img\"><img ng-src=\"{{ course.middlePicture | coverPic }}\" img-error=\"course\"></div><div class=\"ui-list-info\"><h2 class=\"ui-nowrap ui-list-title\">{{ course.title }}</h2><p class=\"bottom price-body\"><span class=\"origin-price\">{{ course.price | formatPrice }} <s class=\"discount-color\" ng-if=\"course.discountId > 0\">{{ course.originPrice | formatPrice }}</s></span></p></div></li></ul><list-empty-view data=\"data.course.data\" title=\"暂时没有收藏课程\"></list-empty-view></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/myfavorite_live.html',
    "<div class=\"ui-scroller course-card\" ng-controller=\"MyFavoriteLiveController\"><ul class=\"ui-list\"><li class=\"ui-border-t ui-list-avatar\" ng-repeat=\"course in data.live.data\" ng-click=\"gotoNativeDetailCoursePage(course.id)\"><div class=\"ui-list-img\"><img ng-src=\"{{ course.middlePicture | coverPic }}\" img-error=\"course\"></div><div class=\"ui-list-info\"><h2 class=\"ui-nowrap ui-list-title\">{{ course.title }}</h2><p class=\"bottom price-body\"><span class=\"origin-price\">{{ course.price | formatPrice }} <s class=\"discount-color\" ng-if=\"course.discountId > 0\">{{ course.originPrice | formatPrice }}</s></span></p></div></li></ul><list-empty-view data=\"data.live.data\" title=\"暂时没有收藏直播课程\"></list-empty-view></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/mygroup.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">我发表的</h3></div></div><div class=\"ui-tab tab-top\" ui-tab><ul class=\"ui-tab-nav ui-border-b\"><li><span class=\"line\">问答</span></li><li><span class=\"line\">笔记</span></li><li><span>讨论</span></li></ul><ul class=\"ui-tab-content tab-display ui-course-learn\"><li><div ng-include=\" 'view/mygroup_question.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/mygroup_note.html' | coverIncludePath \"></div></li><li><div ng-include=\" 'view/mygroup_thread.html' | coverIncludePath \"></div></li></ul></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/mygroup_note.html',
    "<div ng-controller=\"MyGroupNoteController\"><div class=\"ui-scroller\" ui-scroll data=\"data\" on-infinite=\"loadMore()\"><ul class=\"ui-list ui-list-card ui-question\"><li class=\"ui-border-t\" ng-repeat=\"note in data\" ui-sref=\"note({ noteId : note.id })\"><div class=\"ui-list-info\"><h4 class=\"padding\">{{ note.title }}</h4><p class=\"padding\">{{ note.content | blockStr : 50 }}</p><ul class=\"ui-grid-halve padding\"><li class=\"ui-nowrap\">{{ note.lessonTitle }}</li><li>{{ question.updatedTime | coverLearnTime }}</li></ul></div></li></ul><list-empty-view data=\"data\" title=\"暂时没有笔记\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoad\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/mygroup_question.html',
    "<div ng-controller=\"MyGroupQuestionController\"><div class=\"ui-scroller\" ui-scroll data=\"courses\" on-infinite=\"loadMore()\"><ul class=\"ui-list ui-list-card ui-question\"><li class=\"ui-border-t\" ng-repeat=\"question in data\" ui-sref=\"question({ courseId : question.courseId, threadId : question.id })\"><div class=\"ui-list-info\"><h4 class=\"padding\">{{ question.title }}</h4><p class=\"padding\">{{ question.latestPostContent | blockStr : 50 }}</p><ul class=\"ui-grid-trisect padding\"><li class=\"ui-nowrap\">{{ question.courseTitle }}</li><li>{{ question.latestPostTime | coverLearnTime }}</li><li>{{ question.postNum }}个回复</li></ul></div></li></ul><list-empty-view data=\"courses\" title=\"暂时没有课程\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoad\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/mygroup_thread.html',
    "<div ng-controller=\"MyGroupThreadController\"><div class=\"ui-scroller\" ui-scroll data=\"data\" on-infinite=\"loadMore()\"><ul class=\"ui-list ui-list-card ui-question\"><li class=\"ui-border-t\" ng-repeat=\"question in data\" ui-sref=\"question({ courseId : question.courseId, threadId : question.id })\"><div class=\"ui-list-info\"><h4 class=\"padding\">{{ question.title }}</h4><p class=\"padding\">{{ question.latestPostContent | blockStr : 50 }}</p><ul class=\"ui-grid-trisect padding\"><li class=\"ui-nowrap\">{{ question.courseTitle }}</li><li>{{ question.latestPostTime | coverLearnTime }}</li><li>{{ question.postNum }}个回复</li></ul></div></li></ul><list-empty-view data=\"data\" title=\"暂时没有课程\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoad\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/myinfo.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">用户信息</h3><a class=\"ui-btn btn-outline bar-tool small\" ng-show=\"isChange\" ng-click=\"updateUserProfile()\">更新</a></div></div><div class=\"top-header ui-userinfo\" ng-init=\"loadUserInfo()\"><ul class=\"ui-list ui-list-text ui-list-active ui-list-cover\"><li class=\"ui-border-t\"><div class=\"ui-list-info\"><h4>头像</h4></div><div class=\"ui-avatar\"><img class=\"avatar\" ng-src=\"{{ userinfo.mediumAvatar | coverAvatar }}\" img-error=\"avatar\"></div><input type=\"hidden\" ng-model=\"userinfo.fileId\"> <input ng-click=\"showSelectImage($event)\" type=\"file\" id=\"uploadFile\" name=\"file\" class=\"upload-file\" accept=\"image/*\" onchange=\"angular.element(this).scope().uploadChange(this)\"></li></ul><div class=\"ui-form ui-border-t\"><div class=\"ui-form-item ui-border-b\"><label>用户名</label><input type=\"text\" ng-change=\"formChange()\" placeholder=\"暂无昵称\" ng-model=\"userinfo.nickname\"></div><div class=\"ui-form-item ui-border-b\"><label>性别</label><div class=\"ui-select\"><select ng-model=\"userinfo.gender\" ng-change=\"formChange()\" ng-options=\"gener | coverGender for gener in generArray\"></select></div></div><div class=\"ui-form-item ui-form-item-textarea ui-border-b\"><label>个性签名</label><textarea placeholder=\"暂无个性签名\" ng-change=\"formChange()\" ng-model=\"userinfo.signature\"></textarea></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/mylearn.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">我的学习</h3></div></div><div class=\"ui-tab tab-top ui-scroller ui-courselist\" ui-tab><ul class=\"ui-tab-nav ui-border-b\"><li><span class=\"line\">课程</span></li><li><span class=\"line\">直播课</span></li><li><span>班级</span></li></ul><ul class=\"ui-tab-content tab-display ui-course-learn\"><li><div class=\"ui-scroller course-card\" ui-scroll data=\"course.data\"><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t ui-list-avatar\" ng-repeat=\"course in course.data\" ng-click=\"gotoNativeDetailCoursePage(course.id)\"><div class=\"ui-list-img\"><span class=\"finishedTag\" ng-if=\"course.memberIsLearned\"></span> <img ng-src=\"{{ course.middlePicture | coverPic }}\" img-error=\"course\"></div><div class=\"ui-list-info\"><h2 class=\"ui-nowrap ui-list-title\">{{ course.title }}</h2><p><span>上次学习时间:{{ course.startTime | coverLearnTime }}</span><div class=\"ui-progress\"><div class=\"ui-progress-bg\"><span ng-style=\"course | coverLearnProsser\"></span></div></div></p></div></li></ul><list-empty-view data=\"course.data\" title=\"暂时没有在学课程\"></list-empty-view><!--\r" +
    "\n" +
    "              <div class=\"ui-loading-wrap\" ng-show=\"canLoadMore('course')\">\r" +
    "\n" +
    "                <p>正在加载中...</p>\r" +
    "\n" +
    "                <i class=\"ui-loading\"></i>\r" +
    "\n" +
    "              </div>\r" +
    "\n" +
    "--></div></li><li ng-onload=\"loadLiveCourses()\"><div class=\"ui-scroller course-card\" ui-scroll data=\"live.data\" on-infinite=\"loadMore('live', successCallback)\"><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t ui-list-avatar\" ng-repeat=\"course in live.data\" ng-click=\"gotoNativeDetailCoursePage(course.id)\"><div class=\"ui-list-img\"><img ng-src=\"{{ course.middlePicture | coverPic }}\" img-error=\"course\"></div><div class=\"ui-list-info\"><h2 class=\"ui-nowrap ui-list-title\">{{ course.title }}</h2><p><span>上次学习时间:{{ course.startTime | coverLearnTime }}</span><div class=\"ui-progress\"><div class=\"ui-progress-bg\"><span ng-style=\"course | coverLearnProsser\"></span></div></div></p></div></li></ul><list-empty-view data=\"live.data\" title=\"暂时没有在学直播\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoadMore('live')\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div></li><li ng-onload=\"loadClassRooms()\"><div class=\"ui-scroller course-card\" ui-scroll data=\"classroom.data\"><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t ui-list-avatar\" ng-repeat=\"classroom in classroom.data\" ng-click=\"gotoNativeDetailClassroomPage(classroom.id)\"><div class=\"ui-list-img\"><img ng-src=\"{{ classroom.middlePicture | coverPic }}\" img-error=\"classroom\"></div><div class=\"ui-list-info\"><h2 class=\"ui-nowrap ui-list-title\">{{ classroom.title }}</h2><p><span>上次学习时间:{{ classroom.startTime | coverLearnTime }}</span><div class=\"ui-progress\"><div class=\"ui-progress-bg\"><span ng-style=\"classroom | coverLearnProsser\"></span></div></div></p></div></li></ul><list-empty-view data=\"classroom.data\" title=\"暂时没有在学班级\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoadMore('classroom')\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div></li></ul></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/note.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">笔记详情</h3></div></div><div class=\"top-header ui-question\"><section class=\"ui-panel ui-panel-card ui-question-panel\"><h2 class=\"ui-arrowlink ui-nowrap\" ng-href=\"#/lesson/{{ note.courseId }}/{{ note.lessonId }}\">{{ note.lessonTitle }}</h2><ul class=\"ui-list ui-list-text ui-border-t\"><li><h4>{{ note.title }}</h4></li><li><div class=\"ui-list-info\"><div class=\"ui-question-panel content\" ng-bind-html=\"note.content\"></div></div></li></ul></section></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/question.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">问答详情</h3></div></div><div class=\"top-header ui-question\"><section class=\"ui-panel ui-panel-card ui-question-panel\"><h2 class=\"ui-arrowlink\" ng-href=\"#/course/{{ thread.courseId }}\">{{ thread.courseTitle }}</h2><ul class=\"ui-list ui-list-text ui-border-tb\"><li><h4>{{ thread.title }}</h4></li><li><div class=\"ui-avatar\"><img ng-src=\"{{ thread.user.mediumAvatar }}\" img-error=\"avatar\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\">{{ thread.user.nickname }}</h4><p class=\"ui-nowrap\">{{ thread.latestPostTime | coverLearnTime }}</p></div></li><li><div class=\"ui-list-info\"><div class=\"ui-question-panel content\" ng-bind-html=\"thread.content\"></div><div class=\"ui-question-panel tool-bar\"><span><i class=\"iconfont icon-visibility\"></i> {{ thread.hitNum }}</span> <span><i class=\"iconfont icon-modecomment\"></i> {{ thread.postNum }}</span></div></div></li></ul></section><section class=\"ui-panel ui-panel-card ui-question-panel\"><h2><span>教师回答({{ teacherPosts.length }})</span></h2><ul class=\"ui-list ui-list-text\" ng-repeat=\"teacherPost in teacherPosts\"><li><div class=\"ui-avatar-s\"><img ng-src=\"{{ teacherPost.user.mediumAvatar}}\" img-error=\"avatar\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\">{{ teacherPost.user.nickname }}</h4><p class=\"ui-nowrap\">{{ teacherPost.latestPostTime | coverLearnTime }}</p></div></li><li class=\"ui-border-b\"><div class=\"ui-list-info ui-question-panel content\" ng-bind-html=\"teacherPost.content\"></div></li></ul></section><section class=\"ui-panel ui-panel-card ui-question-panel ui-border-t\" style=\"margin-top : -1px\"><h2><span>所有回答({{ threadPosts.length }})</span></h2><ul class=\"ui-list ui-list-text\" ng-repeat=\"threadPost in threadPosts\"><li><div class=\"ui-avatar-s\"><img ng-src=\"{{ threadPost.user.mediumAvatar}}\" img-error=\"avatar\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\">{{ threadPost.user.nickname }}</h4><p class=\"ui-nowrap\">{{ threadPost.latestPostTime | coverLearnTime }}</p></div></li><li class=\"ui-border-b\"><div class=\"ui-list-info ui-question-panel content\" ng-bind-html=\"threadPost.content\"></div></li></ul></section></div><!-- \r" +
    "\n" +
    "<ion-header-bar class=\"bar-positive\">\r" +
    "\n" +
    "<a class=\"button button-icon iconfont icon-fanhui\" back=\"go\">\r" +
    "\n" +
    "</a>\r" +
    "\n" +
    "\r" +
    "\n" +
    "<h1 class=\"title\">问答详情</h1>\r" +
    "\n" +
    "</ion-header-bar>\r" +
    "\n" +
    "<ion-content class=\"question\">\r" +
    "\n" +
    "    <div class=\"list\">\r" +
    "\n" +
    "      <a class=\"item item-icon-left item-icon-right lessonlabel\" href=\"#\">\r" +
    "\n" +
    "        <i class=\"icon\"></i>\r" +
    "\n" +
    "        {{ thread.title }}\r" +
    "\n" +
    "        <i class=\"icon iconfont icon-chevronright\"></i>\r" +
    "\n" +
    "    </a>\r" +
    "\n" +
    "    <a class=\"item title\">\r" +
    "\n" +
    "        {{ thread.courseTitle }}\r" +
    "\n" +
    "    </a>\r" +
    "\n" +
    "\r" +
    "\n" +
    "    <a class=\"item item-avatar question-content\" href=\"#\">\r" +
    "\n" +
    "      \r" +
    "\n" +
    "      <img ng-src=\"{{ thread.user.mediumAvatar }}\">\r" +
    "\n" +
    "      <div class=\"userinfo\">\r" +
    "\n" +
    "          <h2>{{ thread.user.nickname }}</h2>\r" +
    "\n" +
    "          <p>{{ thread.latestPostTime }}</p>\r" +
    "\n" +
    "      </div>\r" +
    "\n" +
    "      <div class=\"content\" ng-bind-html=\"thread.content\">\r" +
    "\n" +
    "      </div>\r" +
    "\n" +
    "\r" +
    "\n" +
    "      <p class=\"hit\">\r" +
    "\n" +
    "        <span>\r" +
    "\n" +
    "              <i class=\"iconfont icon-visibility\"></i>\r" +
    "\n" +
    "              {{ thread.hitNum }}\r" +
    "\n" +
    "        </span>\r" +
    "\n" +
    "        <span>\r" +
    "\n" +
    "              <i class=\"iconfont icon-modecomment\"></i>\r" +
    "\n" +
    "              {{ thread.postNum }}\r" +
    "\n" +
    "        </span>\r" +
    "\n" +
    "      </p>\r" +
    "\n" +
    "    </a>\r" +
    "\n" +
    "    <div class=\"list theadpost\">\r" +
    "\n" +
    "      <p class=\"postlabel\">所有回答({{ threadPosts.length }})</p>\r" +
    "\n" +
    "      \r" +
    "\n" +
    "      <a class=\"item item-avatar\" ng-repeat=\"threadPost in threadPosts\">\r" +
    "\n" +
    "            <img ng-src=\"{{ threadPost.user.mediumAvatar}}\">\r" +
    "\n" +
    "            <div class=\"userinfo\">\r" +
    "\n" +
    "              <h2>{{ threadPost.user.nickname }}</h2>\r" +
    "\n" +
    "              <p>{{ threadPost.createdTime }}</p>\r" +
    "\n" +
    "            </div>\r" +
    "\n" +
    "            <div class=\"content\" ng-bind-html=\"threadPost.content\">\r" +
    "\n" +
    "            </div>\r" +
    "\n" +
    "      </a>\r" +
    "\n" +
    "      <ion-infinite-scroll\r" +
    "\n" +
    "          ng-if=\"!threadPosts\"\r" +
    "\n" +
    "          on-infinite=\"loadTheadPost()\"\r" +
    "\n" +
    "          distance=\"1%\">\r" +
    "\n" +
    "      </ion-infinite-scroll>\r" +
    "\n" +
    "    </div>\r" +
    "\n" +
    "\r" +
    "\n" +
    "  </div>\r" +
    "\n" +
    "  </ion-content>\r" +
    "\n" +
    "\r" +
    "\n" +
    "</div> -->"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/regist.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">注 册</h3></div></div><div class=\"ui-tab tab-top sign login\" ui-tab><ul class=\"ui-tab-nav ui-border-b\"><li><span class=\"line\">手机号注册</span></li><li><span>邮箱注册</span></li></ul><ul class=\"ui-tab-content tab-display top-tab-header ui-scroller\" style=\"top : 0;padding-top : 90px\"><li><div class=\"ui-form\"><div class=\"ui-form-item ui-form-item-r ui-border-b\"><input type=\"text\" maxlength=\"15\" placeholder=\"请输入手机号\" ng-model=\"user.phone\"> <button type=\"button\" class=\"ui-border-l ui-btn-code\" ng-click=\"sendSmsCode(user.phone)\">发送验证码</button> <a class=\"ui-icon-close\" ng-show=\"user.phone.length > 0\" ng-click=\"user.phone = '' \"></a></div><div class=\"ui-form-item ui-form-item-pure ui-border-b margin-t\"><input placeholder=\"请输入验证码\" ng-model=\"user.code\"> <a class=\"ui-icon-close\" ng-show=\"user.code.length > 0\" ng-click=\"user.code = '' \"></a></div><div class=\"ui-form-item ui-form-item-pure ui-border-b margin-t\"><input type=\"password\" placeholder=\"请输入密码\" ng-model=\"user.password\"> <a class=\"ui-icon-close\" ng-show=\"user.password.length > 0\" ng-click=\"user.password = '' \"></a></div><div class=\"ui-btn-wrap padding-none margin-t\"><button class=\"ui-btn-lg btn-green\" ng-click=\"registWithPhone(user)\">注 册</button></div></div></li><li><div class=\"ui-form\"><div class=\"ui-form-item ui-form-item-pure ui-border-b\"><input type=\"text\" placeholder=\"请输入邮箱\" ng-model=\"user.email\"> <a class=\"ui-icon-close\" ng-show=\"user.email.length > 0\" ng-click=\"user.email = '' \"></a></div><div class=\"ui-form-item ui-form-item-pure ui-border-b margin-t\"><input type=\"password\" placeholder=\"请输入密码\" ng-model=\"user.password\"> <a class=\"ui-icon-close\" ng-show=\"user.password.length > 0\" ng-click=\"user.password = '' \"></a></div><div class=\"ui-btn-wrap padding-none margin-t\"><button class=\"ui-btn-lg btn-green\" ng-click=\"registWithEmail(user)\">注 册</button></div></div></li></ul></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/regist_email.html',
    "<ion-view><ion-content class=\"padding\"><div class=\"list sign\"><label class=\"item item-input\"><input type=\"email\" placeholder=\"请输入邮箱\" ng-blur=\"emailstyle=''\" ng-focus=\"emailstyle='active'\" ng-model=\"user.email\" ng-class=\"emailstyle\"></label><label class=\"item item-input\"><input type=\"password\" placeholder=\"请输入密码\" ng-blur=\"passstyle=''\" ng-focus=\"passstyle='active'\" ng-model=\"user.password\" ng-class=\"passstyle\"></label></div><div class=\"sign-padding\"><button class=\"button button-block button-green\" ng-click=\"registWithEmail(user)\">注 册</button></div></ion-content></ion-view>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/regist_phone.html',
    "<ion-view><ion-content class=\"padding content-padding\"><div class=\"list sign\"><a class=\"item item-input\"><input type=\"text\" maxlength=\"14\" placeholder=\"请输入手机号\" ng-blur=\"nkstyle=''\" ng-focus=\"nkstyle='active'\" ng-model=\"user.phone\" ng-class=\"nkstyle\"> <button class=\"button button-code\" ng-click=\"sendSmsCode(user.phone)\">发送验证码</button></a><label class=\"item item-input\"><input type=\"password\" placeholder=\"请输入验证码\" ng-blur=\"codestyle=''\" ng-model=\"user.code\" ng-focus=\"codestyle='active'\" ng-class=\"codestyle\"></label><label class=\"item item-input\"><input type=\"password\" placeholder=\"请输入密码\" ng-blur=\"passstyle=''\" ng-model=\"user.password\" ng-focus=\"passstyle='active'\" ng-class=\"passstyle\"></label></div><div class=\"sign-padding\"><button class=\"button button-block button-green\" ng-click=\"registWithPhone(user)\">注 册</button></div></ion-content></ion-view>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/search.html',
    "<div class=\"ui-bar search-bar\"><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><div class=\"title\"><div class=\"ui-searchbar-wrap ui-border-b focus\" on-element-readey=\"focusSearchInput()\"><div class=\"ui-searchbar ui-border-radius\"><i class=\"ui-icon-search\"></i><div class=\"ui-searchbar-text\">搜索课程,班级</div><div class=\"ui-searchbar-input\"><input ng-model=\"search\" ng-keypress=\"inputKeyPress($event)\" placeholder=\"搜索课程,班级\" autocapitalize=\"off\"></div><i class=\"ui-icon-close\" ng-click=\"search = '' \"></i></div><button class=\"ui-searchbar-cancel\" ng-click=\"seach()\">{{ search.length > 0 ? '搜索' : '取消' }}</button></div></div></div></div><div class=\"top-header ui-scroller\"><div class=\"course-card\" style=\"margin-bottom: 16px\" ng-if=\"searchCourse.data.length > 0\"><h4><span class=\"circle-label\"></span>课程</h4><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"course in searchCourse.data\" ng-click=\"gotoNativeDetailCoursePage(course.id)\" ng-include=\" 'view/course_list_item.html' | coverIncludePath \"></li></ul><div class=\"ui-btn-group\" ng-if=\"searchCourse.data.length < searchCourse.total\"><button type=\"button\" class=\"btn-green\" ng-href=\"#/search/course/{{ search }}\">更多</button></div></div><div class=\"course-card classroom-card\" ng-if=\"searchClassRoom.data.length > 0\"><h4><span class=\"circle-label\"></span>班级</h4><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"classRoom in searchClassRoom.data\" ng-click=\"gotoNativeDetailClassroomPage(classRoom.id)\" ng-include=\" 'view/classroom_list_item.html' | coverIncludePath \"></li></ul><div class=\"ui-btn-group\" ng-if=\"searchClassRoom.data.length < searchClassRoom.total\"><button type=\"button\" class=\"btn-green\" ng-href=\"#/search/classroom/{{ search }}\">更多</button></div></div><div class=\"list-empty\" ng-if=\"searchClassRoom.data.length == 0 && searchCourse.data.length == 0\"><a><i class=\"icon iconfont icon-ebook\"></i> <span>没有搜到到相关课程或班级</span></a></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/search_classroom_result.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">搜索:{{ search }}</h3></div></div><div class=\"top-header ui-scroller\"><div class=\"course-card classroom-card\" ng-if=\"searchClassRoom.data.length > 0\"><h4><span class=\"circle-label\"></span>班级</h4><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"classRoom in searchClassRoom.data\" ng-click=\"\r" +
    "\n" +
    "          gotoNativeDetailClassroomPage(classRoom.id)\" ng-include=\" 'view/classroom_list_item.html' | coverIncludePath \"></li></ul></div><div class=\"list-empty\" ng-if=\"searchClassRoom.data.length == 0\"><a><i class=\"icon iconfont icon-ebook\"></i> <span>没有搜到到相关班级</span></a></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/search_course.html',
    "<div class=\"ui-bar search-bar\"><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><div class=\"title\"><div class=\"ui-searchbar-wrap ui-border-b focus\" on-element-readey=\"focusSearchInput()\"><div class=\"ui-searchbar ui-border-radius\"><i class=\"ui-icon-search\"></i><div class=\"ui-searchbar-text\">搜索课程</div><div class=\"ui-searchbar-input\"><input ng-model=\"search\" ng-keypress=\"inputKeyPress($event)\" placeholder=\"搜索课程\" autocapitalize=\"off\"></div><i class=\"ui-icon-close\" ng-click=\"search = '' \"></i></div><button class=\"ui-searchbar-cancel\" ng-click=\"seach()\">{{ search.length > 0 ? '搜索' : '取消' }}</button></div></div></div></div><div class=\"top-header ui-scroller course-card\" ui-scroll data=\"searchDatas\" on-infinite=\"loadMore()\"><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"course in searchDatas\" ng-href=\"#/course/{{ course.id }}\"><div class=\"ui-list-img\"><img ng-src=\"{{ course.middlePicture }} \" img-error=\"course\"> <span class=\"discount-label\" ng-class=\"course.discount == 0 ? 'free' : 'rebate' \" ng-if=\"course.discountId > 0\"><span class=\"discount-label-bottom\"></span> <span class=\"discount-label-content\" ng-if=\"course.discount == 0\">限时免费</span> <span class=\"discount-label-content\" ng-if=\"course.discount > 0\">限时打折</span></span></div><div class=\"ui-list-info\"><h2 class=\"ui-nowrap ui-list-title\">{{ course.title }}</h2><p class=\"bottom price-body\"><span class=\"origin-price\">{{ course.price | formatPrice }} <s class=\"discount-color\" ng-if=\"course.discountId > 0\">{{ course.originPrice | formatPrice }}</s></span> <span class=\"right\"><i class=\"iconfont icon-person\"></i> {{ course.studentNum }}人在学</span></p></div></li></ul><list-empty-view data=\"searchDatas\" title=\"没有搜索到神马\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoad\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/search_course_result.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">搜索:{{ search }}</h3></div></div><div class=\"top-header ui-scroller\"><div class=\"course-card\" style=\"margin-bottom: 16px\" ng-if=\"searchCourse.data.length > 0\"><h4><span class=\"circle-label\"></span>课程</h4><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"course in searchCourse.data\" ng-click=\"gotoNativeDetailCoursePage(course.id)\" ng-include=\" 'view/course_list_item.html' | coverIncludePath \"></li></ul></div><div class=\"list-empty\" ng-if=\"searchCourse.data.length == 0\"><a><i class=\"icon iconfont icon-ebook\"></i> <span>没有搜到到相关课程</span></a></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/setting.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">设 置</h3></div></div><div class=\"top-header ui-userinfo\"><ul class=\"ui-list ui-list-text ui-list-link ui-list-cover\"><li class=\"ui-border-b\"><h4 class=\"ui-nowrap\">扫描进入网校</h4></li></ul><div ng-if=\"isShowLogoutBtn\" class=\"ui-btn-wrap\" style=\"margin-top : 16px\"><button class=\"ui-btn-lg btn-red\" ng-click=\"logout()\">退出账号</button></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/teacher_list.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">{{ title }}</h3></div></div><div class=\"top-header ui-scroller\" ui-scroll data=\"users\" ng-init=\"loadUsers()\" on-infinite=\"loadMore(successCallback)\"><ul class=\"ui-list ui-list-text\"><li class=\"ui-border-t\" ng-repeat=\"user in users\" ui-sref=\"userInfo({ userId : user.id })\"><div class=\"ui-avatar-s\"><img ng-src=\"{{ getUserAvatar(user) | coverAvatar }}\" img-error=\"avatar\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\">{{ user.nickname }}<label style=\"bottom:2px\" ng-if=\" user.roles | isTeacherRole\" class=\"ui-label\">教师</label></h4><p class=\"ui-nowrap\">{{ user.title }}</p></div></li></ul><list-empty-view class=\"lesson-empty\" data=\"users\" title=\"{{ emptyStr }}\"></list-empty-view><div class=\"ui-loading-wrap\" ng-show=\"canLoad\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/teaching_thread_list.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">所有问答</h3></div></div><div class=\"top-header ui-todolist ui-scroller\"><div class=\"ui-tab tab-top\" ui-tab><ul class=\"ui-tab-nav ui-border-b\" style=\"position:absolute\"><li><span>未回答</span></li><li><span>已回答</span></li></ul><ul class=\"ui-tab-content tab-display\"><li><section class=\"ui-panel ui-panel-card ui-border-t\" ng-controller=\"ThreadTeachingController\" ng-init=\"initQuestionResult(10000)\"><h2 class=\"title-body\" style=\"margin-top:50px\"><span class=\"title\"><span class=\"circle-label\"></span> 提问回答</span> <a class=\"title-tips\">问题总数:<label>{{ teachingResult.threadCount }}</label></a></h2><div class=\"todo-card\"><list-empty-view data=\"teachingResult.threads\" title=\"暂时没有待回答问题\"></list-empty-view><ul class=\"ui-list ui-list-pure ui-border-t\"><li ng-repeat=\"thread in teachingResult.threads | orderBy:'createdTime':true\" class=\"ui-border-t\"><div class=\"ui-list-info\" ng-click=\"showThreadChatView(thread)\" ng-if=\"thread.isTeacherAnswer <= 0\"><h2 class=\"ui-nowrap\"><span class=\"radius-label\" ng-class=\"'red'\">未回答</span> {{ thread.title }}</h2><p>{{ thread.lessonTitle }}</p><div class=\"bottom ui-border-t\"><div class=\"ui-avatar-s rr\"><img ng-src=\"{{ thread.user.avatar | coverAvatar }}\"></div><span class=\"bottom-label\">{{ thread.user.nickname }} <span class=\"bottom-label-bg\">{{ thread.user.roles | coverUserRole }}</span></span> <span class=\"bottom-label right\">{{ thread.createdTime | coverLearnTime }}</span></div></div></li></ul><div class=\"ui-btn-group\" ng-if=\"teachingResult.threads.length < teachingResult.threadCount\"><button type=\"button\" class=\"btn-green\">更多</button></div></div></section></li><li><section class=\"ui-panel ui-panel-card ui-border-t\" ng-controller=\"ThreadTeachingController\" ng-init=\"initQuestionResult(10000)\"><h2 class=\"title-body\" style=\"margin-top:50px\"><span class=\"title\"><span class=\"circle-label\"></span> 提问回答</span> <a class=\"title-tips\">问题总数:<label>{{ teachingResult.threadCount }}</label></a></h2><div class=\"todo-card\"><list-empty-view data=\"teachingResult.threads\" title=\"暂时没有待回答问题\"></list-empty-view><ul class=\"ui-list ui-list-pure ui-border-t\"><li ng-repeat=\"thread in teachingResult.threads | orderBy:'createdTime':true\" class=\"ui-border-t\"><div class=\"ui-list-info\" ng-click=\"showThreadChatView(thread)\" ng-if=\"thread.isTeacherAnswer > 0\"><h2 class=\"ui-nowrap\"><span class=\"radius-label\" ng-class=\"'blue'\">已回答</span> {{ thread.title }}</h2><p>{{ thread.lessonTitle }}</p><div class=\"bottom ui-border-t\"><div class=\"ui-avatar-s rr\"><img ng-src=\"{{ thread.user.avatar | coverAvatar }}\"></div><span class=\"bottom-label\">{{ thread.user.nickname }} <span class=\"bottom-label-bg\">{{ thread.user.roles | coverUserRole }}</span></span> <span class=\"bottom-label right\">{{ thread.createdTime | coverLearnTime }}</span></div></div></li></ul><div class=\"ui-btn-group\" ng-if=\"teachingResult.threads.length < teachingResult.threadCount\"><button type=\"button\" class=\"btn-green\">更多</button></div></div></section></li></ul></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/todolist.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">{{ title }}</h3></div></div><div class=\"top-header ui-scroller\" ng-init=\"init()\"><div class=\"ui-todolist\" ng-init=\"initChartData()\"><section class=\"\" ng-controller=\"CourseCardController\"></section><section class=\"ui-panel ui-panel-card ui-border-t\"><h2 class=\"title-body ui-border-b\"><span class=\"title\">数据浏览</span></h2><div class=\"ui-slider todo-slider\" slider=\"todo-slider\" ui-slider-box=\"charts\" on-load=\"loadCharts()\" auto=\"true\"><ul class=\"ui-slider-content ui-border-b\"><li ng-repeat=\"chart in charts\"><ul class=\"ui-grid-halve todo-header ui-border-b\"><li class=\"ui-border-r\"><span class=\"label red\">{{ chart.header[0].value }}</span> {{ chart.header[0].title }}</li><li><span class=\"label blue\">{{ chart.header[1].value }}</span> {{ chart.header[1].title }}</li></ul><div class=\"chart-container\"><h4>{{ chart.chartLabel }}</h4><canvas class=\"list-chart\" id=\"chart_{{ $index }}\"></canvas></div></li></ul></div></section><section class=\"ui-panel ui-panel-card ui-border-t\" ng-controller=\"ThreadTeachingController\" ng-init=\"initQuestionResult(3)\"><h2 class=\"title-body\"><span class=\"title\"><span class=\"circle-label\"></span> 提问回答</span> <a class=\"title-tips\">问题总数:<label>{{ teachingResult.threadCount }}</label></a></h2><div class=\"todo-card\"><list-empty-view data=\"teachingResult.threads\" title=\"暂时没有待回答问题\"></list-empty-view><ul class=\"ui-list ui-list-pure ui-border-t\"><li ng-repeat=\"thread in teachingResult.threads | orderBy:'createdTime':true\" class=\"ui-border-t\"><div class=\"ui-list-info\" ng-click=\"showThreadChatView(thread)\" ng-if=\"thread.isTeacherAnswer <= 0\"><h2 class=\"ui-nowrap\"><span class=\"radius-label\" ng-class=\"'red'\">未回答</span> {{ thread.title }}</h2><p>{{ thread.lessonTitle }}</p><div class=\"bottom ui-border-t\"><div class=\"ui-avatar-s rr\"><img ng-src=\"{{ thread.user.avatar | coverAvatar }}\"></div><span class=\"bottom-label\">{{ thread.user.nickname }} <span class=\"bottom-label-bg\">{{ thread.user.roles | coverUserRole }}</span></span> <span class=\"bottom-label right\">{{ thread.createdTime | coverLearnTime }}</span></div></div></li></ul><div class=\"ui-btn-group\" ng-if=\"teachingResult.threads.length < teachingResult.threadCount\"><button type=\"button\" class=\"btn-green\" ng-href=\"#/teaching/threadlist/{{ courseId }}\">更多</button></div></div></section></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/user_info.html',
    "<div class=\"ui-bar transparent\" ng-class=\"uiBarTransparent ? 'transparent' : '' \" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">用户信息</h3></div></div><div class=\"ui-details ui-scroller\" ui-scroll data=\"userinfo\" on-scroll=\"changeTabStatus(headTop, scrollTop)\" ng-init=\"loadUserInfo()\" on-infinite=\"loadMore(successCallback)\"><ul class=\"ui-list transparent ui-details-panel ui-details-head\"><li><div class=\"ui-details-avatar\"><div class=\"ui-avatar-lg\"><img class=\"avatar\" ng-src=\"{{ userinfo.mediumAvatar | coverAvatar }}\" img-error=\"avatar\"></div><h4 class=\"ui-nowrap\">{{ userinfo.nickname }}</h4><p class=\"ui-nowrap\">{{ userinfo.signature }}</p><button ng-if=\"isUnOwner()\" class=\"ui-btn btn-green\" ng-click=\"changeFollowUser()\" ng-if=\"isFollower != null \">{{ isFollower ? \"已关注\" : \"+关注\" }}</button></div></li></ul><div class=\"ui-panel\"><div class=\"ui-border-b ui-details-panel ui-vip\"><ul class=\"ui-list ui-border-b\"><li><ul class=\"ui-grid-trisect\"><li><h4>{{ userinfo.following }}</h4><p>关注</p></li><li><h4>{{ userinfo.follower }}</h4><p>粉丝</p></li><li><h4>{{ courses.length }}</h4><p>课程</p></li></ul></li><li class=\"vip-price-line\"><span>个人介绍</span></li></ul><div class=\"ui-btn-wrap\"><h4 ng-bind-html=\"userinfo.about\"></h4></div></div><div class=\"course-card ui-border-t\" style=\"margin-top : 16px\"><h4>{{ isTeacher ? '在教课程' : '在学课程' }}</h4><list-empty-view data=\"courses\" title=\"getEmptyTitle()\" is-function=\"true\"></list-empty-view><ul class=\"ui-list ui-border-tb\"><li class=\"ui-border-t\" ng-repeat=\"course in courses\" ng-click=\"gotoNativeDetailCoursePage(course.id)\"><div class=\"ui-list-img\"><img class=\"full-image\" ng-src=\"{{ course.largePicture }}\" img-error=\"course\"></div><div class=\"ui-list-info\"><h2 class=\"ui-nowrap ui-list-title\">{{ course.title }}</h2><p class=\"bottom price-body\"><span class=\"origin-price\">{{ course.price | formatPrice }} <s class=\"discount-color\" ng-if=\"course.discountId > 0\">{{ course.originPrice | formatPrice }}</s></span></p></div></li></ul><div class=\"ui-loading-wrap\" ng-show=\"canLoad\"><p>正在加载中...</p><i class=\"ui-loading\"></i></div></div></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/vip_list.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">开通会员</h3></div></div><div class=\"top-header ui-vip ui-scroller\" ng-init=\"loadVipList()\" style=\"background: white\"><ul class=\"ui-list ui-vip-header ui-border-tb\"><li class=\"ui-border-t ui-vip-avatar ui-center\" style=\"height: 180px;background: #03C777\"><div class=\"ui-avatar\"><img ng-src=\"{{ user.mediumAvatar | coverAvatar }}\" img-error=\"avatar\"></div><div class=\"ui-list-info\" style=\"padding-right: 0px\"><h4 class=\"ui-nowrap\" style=\"color: white\">{{ data.user.nickname }}</h4><p class=\"ui-nowrap\" ng-bind=\"getVipName()\"></p></div></li><li class=\"vip-price-line\" style=\"margin-top: -23px\"><span style=\"width: 300px;border-radius: 5px;background: white;color: #03c777;font-weight: bold;font-size: 18px;padding-top: 10px\">会员介绍</span></li></ul><div class=\"ui-panel\" id=\"cardp1\" ng-repeat=\"vip in data.vips\" style=\"margin-top: 36px\"><ul class=\"vip-content ui-list vip-level1\" id=\"cardp2\" ng-if=\"vip.seq == 1\"><li class=\"\" style=\"border-bottom: 2px dashed white\"><div class=\"ui-avatar\"><img ng-src=\"{{ vip.picture }}\" img-error=\"vip\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\">{{ vip.name }}</h4></div><div class=\"ui-list-action ui-vip-price\"><sup>¥</sup> <span>{{ vip.monthPrice }}</span> 1个月</div></li><div class=\"left-circle\"></div><div class=\"right-circle\"></div><li class=\"\" style=\"padding-right: 0px\"><div class=\"ui-list-info\"><div class=\"ui-vip-content\">{{ vip.description | blockStr }}</div><p ng-if=\"! vip.description || vip.description.length == 0\" style=\"color: #efefef;text-align: center\">没有会员简介</p></div></li><div class=\"ui-btn-wrap\"><a class=\"ui-btn-lg ui-center\" ng-click=\"showPayVipPage(vip)\" style=\"border-radius: 50px;color:white; position: relative;right: 0px;border: solid 1px white;background: none\">立即开通</a></div></ul><ul class=\"vip-content ui-list vip-level2\" id=\"cardp2\" ng-if=\"vip.seq == 2\"><li class=\"\" style=\"border-bottom: 2px dashed white\"><div class=\"ui-avatar\"><img ng-src=\"{{ vip.picture }}\" img-error=\"vip\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\">{{ vip.name }}</h4></div><div class=\"ui-list-action ui-vip-price\"><sup>¥</sup> <span>{{ vip.monthPrice }}</span> 1个月</div></li><div class=\"left-circle\"></div><div class=\"right-circle\"></div><li class=\"\" style=\"padding-right: 0px\"><div class=\"ui-list-info\"><div class=\"ui-vip-content\">{{ vip.description | blockStr }}</div><p ng-if=\"! vip.description || vip.description.length == 0\" style=\"color: #efefef;text-align: center\">没有会员简介</p></div></li><div class=\"ui-btn-wrap\"><a class=\"ui-btn-lg ui-center\" ng-click=\"showPayVipPage(vip)\" style=\"border-radius: 50px;color:white;position: relative;right: 0px; border: solid 1px white;background: none\">立即开通</a></div></ul><ul class=\"vip-content ui-list vip-level3\" id=\"cardp2\" ng-if=\"vip.seq == 3\"><li class=\"\" style=\"border-bottom: 2px dashed white\"><div class=\"ui-avatar\"><img ng-src=\"{{ vip.picture }}\" img-error=\"vip\"></div><div class=\"ui-list-info\"><h4 class=\"ui-nowrap\">{{ vip.name }}</h4></div><div class=\"ui-list-action ui-vip-price\"><sup>¥</sup> <span>{{ vip.monthPrice }}</span> 1个月</div></li><div class=\"left-circle\"></div><div class=\"right-circle\"></div><li class=\"\" style=\"padding-right: 0px\"><div class=\"ui-list-info\"><div class=\"ui-vip-content\">{{ vip.description | blockStr }}</div><p ng-if=\"! vip.description || vip.description.length == 0\" style=\"color: #efefef;text-align: center\">没有会员简介</p></div></li><div class=\"ui-btn-wrap\"><a class=\"ui-btn-lg ui-center\" ng-click=\"showPayVipPage(vip)\" style=\"border-radius: 50px;color:white;position: relative;right: 0px; border: solid 1px white;background: none\">立即开通</a></div></ul></div></div>"
  );


  $templateCache.put('/bundles/topxiamobilebundlev2/main/view/vip_pay.html',
    "<div class=\"ui-bar\" ui-bar><div class=\"ui-bar-bg\"><button class=\"ui-btn btn-outline iconfont icon-fanhui\" back=\"go\"></button><h3 class=\"title\">开通会员</h3></div></div><div class=\"top-header ui-vippay ui-course-pay\" ng-init=\"initData()\"><div class=\"ui-form\"><div class=\"ui-form-item ui-list-divider ui-border-b\">选择开通时长</div><div class=\"ui-form-item ui-vippay-item ui-border-b\"><ul class=\"ui-grid-halve\"><li class=\"ui-border-r\"><a ng-click=\"showPopover($event)\">{{ selectedPayMode.title }} <i class=\"iconfont icon-arrowdropdown\"></i></a><ul class=\"ui-list ui-vippay-modal\" ng-show=\"isShowPayMode\"><li class=\"ui-border-b\" ng-repeat=\"payMode in payModes\" ng-click=\"selectPayMode(payMode)\">{{ payMode.title }}</li></ul></li><li><a class=\"ui-vippay-btn iconfont icon-jian btn-gray\" ng-click=\"sub()\"></a> <a class=\"ui-vippay-btn btn-border\">{{ selectedNum }}</a> <a class=\"ui-vippay-btn iconfont icon-jia btn-green\" ng-click=\"add()\"></a></li></ul></div><ul class=\"ui-list ui-list-link ui-list-text ui-border-b\"><li class=\"ui-border-t ui-list-divider\">优惠信息</li><li class=\"ui-border-t\"><div class=\"ui-list-info\"><h4>使用{{ coin.name }} <span class=\"subtitle\">汇率{{ coin.cashRate }}</span></h4></div><label class=\"ui-switch\" ng-if=\"!checkIsCoinMode()\"><input type=\"checkbox\" ng-model=\"payMode\" ng-change=\"changePayMode()\" ng-checked=\"payMode == 'coin' \" ng-if=\"priceType != 'Coin'\"></label></li></ul><div class=\"ui-btn-wrap\"><div class=\"pay-body\">需支付: <span class=\"pay-price\">{{ totalPayPrice | formatPrice}} <span>{{ payMode == 'coin' ? coin.name : '' }}</span></span></div><button class=\"ui-btn-lg btn-yellow\" ng-click=\"pay()\">去支付</button></div></div></div>"
  );

}]);
